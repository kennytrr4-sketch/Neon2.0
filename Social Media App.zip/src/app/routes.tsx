import { createBrowserRouter, Navigate, Outlet } from "react-router";
import { Layout } from "./components/Layout";
import { Feed } from "./pages/Feed";
import { Profile } from "./pages/Profile";
import { Friends } from "./pages/Friends";
import { Notifications } from "./pages/Notifications";
import { Login } from "./pages/Login";
import { LoginHistoryPage } from "./pages/LoginHistoryPage";
import { AdminPanel } from "./pages/AdminPanel";
import { Toaster } from "./components/ui/sonner";

// Root component that just renders outlet for all routes
function Root() {
  return (
    <>
      <Outlet />
      <Toaster />
    </>
  );
}

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      {
        path: "login",
        Component: Login,
      },
      {
        path: "/",
        Component: Layout,
        children: [
          { index: true, Component: Feed },
          { path: "profile/:userId?", Component: Profile },
          { path: "friends", Component: Friends },
          { path: "notifications", Component: Notifications },
          { path: "login-history", Component: LoginHistoryPage },
          { path: "admin", Component: AdminPanel },
        ],
      },
      {
        path: "*",
        element: <Navigate to="/" replace />,
      },
    ],
  },
]);