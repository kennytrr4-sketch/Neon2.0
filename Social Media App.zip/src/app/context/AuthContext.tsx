import React, { createContext, useContext, useState, useEffect } from 'react';
import { mockUsersFromOtherDevices, getRandomNewUser } from '../services/mockUsers';
import { toast } from 'sonner';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  bio?: string;
  location?: string;
  website?: string;
  coverPhoto?: string;
  joined?: string;
  friends?: number;
  isAdmin?: boolean;
  isBanned?: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  isAuthenticated: boolean;
  accessToken: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initialize accounts if they don't exist
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    
    // Check if admin account exists
    const adminExists = mockAccounts.find((acc: any) => acc.email === 'admin@neon.com');
    
    if (!adminExists) {
      // Create admin account
      const adminAccount = {
        id: 'admin-staff',
        email: 'admin@neon.com',
        password: 'admin123',
        name: 'Neon Staff',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
        bio: 'Official Neon Staff Account',
        location: 'Neon HQ',
        website: '',
        joined: 'January 2024',
        friends: 0,
        isAdmin: true,
        isBanned: false
      };
      mockAccounts.push(adminAccount);
    }

    // Check if demo account exists
    const demoExists = mockAccounts.find((acc: any) => acc.email === 'demo@example.com');
    
    if (!demoExists) {
      // Create demo account
      const demoAccount = {
        id: 'demo-user',
        email: 'demo@example.com',
        password: 'Demo123!',
        name: 'Demo User',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=demo',
        bio: 'Demo account for testing',
        location: 'Demo City',
        website: '',
        joined: 'January 2024',
        friends: 0,
        isAdmin: false,
        isBanned: false
      };
      mockAccounts.push(demoAccount);
    }

    // Add mock users from "other devices" if they don't exist
    const hasMockUsers = mockAccounts.some((acc: any) => acc.fromOtherDevice === true);
    if (!hasMockUsers) {
      mockAccounts.push(...mockUsersFromOtherDevices);
    }

    localStorage.setItem('mockAccounts', JSON.stringify(mockAccounts));

    // Check for existing session
    const storedToken = localStorage.getItem('accessToken');
    const storedUser = localStorage.getItem('user');

    if (storedToken && storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setAccessToken(storedToken);
      setUser(parsedUser);
      setIsAuthenticated(true);
    }

    setIsLoading(false);
  }, []);

  // Simulate new users joining from other devices periodically
  useEffect(() => {
    const addNewMockUser = () => {
      const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
      const newUser = getRandomNewUser();
      
      // Check if user with similar email already exists
      const exists = mockAccounts.find((acc: any) => acc.email === newUser.email);
      if (!exists) {
        mockAccounts.push(newUser);
        localStorage.setItem('mockAccounts', JSON.stringify(mockAccounts));
        console.log(`🌐 New user joined from another device: ${newUser.name}`);
        
        // Show toast notification if user is logged in
        if (isAuthenticated) {
          toast.info(`🌐 ${newUser.name} just joined Neon from another device!`, {
            duration: 4000,
          });
        }
      }
    };

    // Add a new mock user every 2-3 minutes to simulate activity
    const interval = setInterval(addNewMockUser, 150000); // 2.5 minutes

    return () => clearInterval(interval);
  }, [isAuthenticated]);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // First, try mock authentication
      const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
      const account = mockAccounts.find((acc: any) => acc.email === email && acc.password === password);

      if (account) {
        // Check if user is banned
        if (account.isBanned && !account.isAdmin) {
          console.error('Login failed: Account is banned');
          return false;
        }

        const user = {
          id: account.id,
          name: account.name,
          email: account.email,
          avatar: account.avatar,
          bio: account.bio,
          location: account.location,
          website: account.website,
          joined: account.joined,
          friends: account.friends,
          isAdmin: account.isAdmin || false,
          isBanned: account.isBanned || false
        };
        const token = `mock-token-${Date.now()}`;

        // Track login activity
        const loginHistory = JSON.parse(localStorage.getItem('loginHistory') || '[]');
        const loginRecord = {
          email: email,
          name: user.name,
          userId: user.id,
          timestamp: new Date().toISOString(),
          date: new Date().toLocaleString(),
          isAdmin: user.isAdmin
        };
        loginHistory.push(loginRecord);
        localStorage.setItem('loginHistory', JSON.stringify(loginHistory));

        setUser(user);
        setAccessToken(token);
        setIsAuthenticated(true);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('accessToken', token);
        return true;
      }

      console.error('Login failed: Invalid credentials');
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const signup = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      // Check if email already exists in mock accounts
      const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
      const existingAccount = mockAccounts.find((acc: any) => acc.email === email);

      if (existingAccount) {
        console.error('Signup failed: Email already exists');
        return false;
      }

      // Create new mock account
      const newAccount = {
        id: `user-${Date.now()}`,
        email,
        password,
        name,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
        bio: '',
        location: '',
        website: '',
        joined: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        friends: 0,
        isAdmin: false,
        isBanned: false
      };

      mockAccounts.push(newAccount);
      localStorage.setItem('mockAccounts', JSON.stringify(mockAccounts));

      // Automatically log in the new user
      return await login(email, password);
    } catch (error) {
      console.error('Signup error:', error);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    setAccessToken(null);
    setIsAuthenticated(false);
    localStorage.removeItem('user');
    localStorage.removeItem('accessToken');
  };

  const updateProfile = async (updates: Partial<User>) => {
    if (!user || !accessToken) return;

    // Update user in mock accounts
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    const accountIndex = mockAccounts.findIndex((acc: any) => acc.id === user.id);

    if (accountIndex !== -1) {
      mockAccounts[accountIndex] = { ...mockAccounts[accountIndex], ...updates };
      localStorage.setItem('mockAccounts', JSON.stringify(mockAccounts));

      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      return;
    }
  };

  if (isLoading) {
    return null; // or a loading spinner
  }

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateProfile, isAuthenticated, accessToken }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}