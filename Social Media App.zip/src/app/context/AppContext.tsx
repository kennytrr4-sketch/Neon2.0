import React, { createContext, useContext, useState, useEffect } from 'react';
import { Post, Notification } from '../types';
import { useAuth } from './AuthContext';

interface AppContextType {
  posts: Post[];
  notifications: Notification[];
  addPost: (post: Post) => void;
  updatePost: (postId: string, updates: Partial<Post>) => void;
  updateUserInPosts: (userId: string, userName: string, userAvatar?: string) => void;
  addNotification: (notification: Notification) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  getUnreadNotificationCount: () => number;
  refreshPosts: () => void;
  refreshNotifications: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { user, accessToken } = useAuth();

  // Load posts from localStorage on mount
  useEffect(() => {
    refreshPosts();
  }, []);

  // Load notifications when user changes
  useEffect(() => {
    if (user) {
      refreshNotifications();
    }
  }, [user]);

  const refreshPosts = async () => {
    try {
      // Load posts from localStorage (forced HMR update to clear stale polling)
      const storedPosts = JSON.parse(localStorage.getItem('posts') || '[]');
      setPosts(storedPosts);
    } catch (error) {
      console.error('Failed to load posts:', error);
    }
  };

  const refreshNotifications = async () => {
    if (!user) return;

    try {
      // Load notifications from localStorage
      const storedNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
      const userNotifications = storedNotifications.filter((n: any) => n.userId === user.id);
      setNotifications(userNotifications);
    } catch (error) {
      console.error('Failed to load notifications:', error);
    }
  };

  const addPost = async (post: Post) => {
    try {
      // Save post to localStorage
      const storedPosts = JSON.parse(localStorage.getItem('posts') || '[]');
      const updatedPosts = [post, ...storedPosts];
      localStorage.setItem('posts', JSON.stringify(updatedPosts));
      setPosts(updatedPosts);
    } catch (error) {
      console.error('Failed to create post:', error);
    }
  };

  const updatePost = async (postId: string, updates: Partial<Post>) => {
    try {
      // Update post in localStorage
      const storedPosts = JSON.parse(localStorage.getItem('posts') || '[]');
      const updatedPosts = storedPosts.map((p: Post) => 
        p.id === postId ? { ...p, ...updates } : p
      );
      localStorage.setItem('posts', JSON.stringify(updatedPosts));
      setPosts(updatedPosts);
    } catch (error) {
      console.error('Failed to update post:', error);
    }
  };

  const updateUserInPosts = (userId: string, userName: string, userAvatar?: string) => {
    setPosts(prev => 
      prev.map(post => 
        post.userId === userId ? { ...post, userName, userAvatar: userAvatar || post.userAvatar } : post
      )
    );
  };

  const addNotification = async (notification: Notification) => {
    try {
      // Save notification to localStorage
      const storedNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
      const updatedNotifications = [notification, ...storedNotifications];
      localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
      setNotifications(prev => [notification, ...prev]);
    } catch (error) {
      console.error('Failed to add notification:', error);
    }
  };

  const markNotificationAsRead = async (id: string) => {
    if (!user) return;

    try {
      // Update notification in localStorage
      const storedNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
      const updatedNotifications = storedNotifications.map((n: any) =>
        n.id === id ? { ...n, read: true } : n
      );
      localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
      setNotifications(prev =>
        prev.map(notif =>
          notif.id === id ? { ...notif, read: true } : notif
        )
      );
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const markAllNotificationsAsRead = async () => {
    if (!user) return;

    try {
      // Update all notifications in localStorage
      const storedNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
      const updatedNotifications = storedNotifications.map((n: any) =>
        n.userId === user.id ? { ...n, read: true } : n
      );
      localStorage.setItem('notifications', JSON.stringify(updatedNotifications));
      setNotifications(prev =>
        prev.map(notif => ({ ...notif, read: true }))
      );
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
    }
  };

  const getUnreadNotificationCount = () => {
    return notifications.filter(n => !n.read).length;
  };

  return (
    <AppContext.Provider value={{
      posts,
      notifications,
      addPost,
      updatePost,
      updateUserInPosts,
      addNotification,
      markNotificationAsRead,
      markAllNotificationsAsRead,
      getUnreadNotificationCount,
      refreshPosts,
      refreshNotifications,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}