import { UserPlus, Users as UsersIcon, User, Search } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { Messenger } from "../components/Messenger";
import { SearchAccountsDialog } from "../components/SearchAccountsDialog";
import { useAuth } from "../context/AuthContext";
import { api } from "../utils/api";

export function Friends() {
  const { user: currentUser } = useAuth();
  const [friendsList, setFriendsList] = useState<any[]>([]);
  const [activeChat, setActiveChat] = useState<{ id: string; name: string; avatar: string } | null>(null);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);

  useEffect(() => {
    if (currentUser) {
      loadFriends();
      loadTotalUsers();
    }
  }, [currentUser]);

  const loadTotalUsers = () => {
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    // Count all users except current user
    const userCount = mockAccounts.filter((acc: any) => acc.id !== currentUser?.id).length;
    setTotalUsers(userCount);
  };

  const loadFriends = async () => {
    if (!currentUser) return;

    try {
      const data = await api.getFriends(currentUser.id);
      if (data.friends) {
        setFriendsList(data.friends);
      }
    } catch (error) {
      console.error('Failed to load friends:', error);
    }
  };

  const handleUnfriend = async (userId: string, userName: string) => {
    if (!currentUser) return;

    try {
      const data = await api.removeFriend(currentUser.id, userId);
      if (data.success) {
        setFriendsList(friendsList.filter(friend => friend.id !== userId));
        toast.info(`Unfriended ${userName}`);
      }
    } catch (error) {
      console.error('Failed to unfriend:', error);
      toast.error('Failed to unfriend user');
    }
  };

  const handleMessage = (user: { id: string; name: string; avatar: string }) => {
    setActiveChat(user);
  };

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button onClick={() => setShowSearchDialog(true)}>
            <Search className="h-4 w-4 mr-2" />
            Search Accounts
          </Button>
          <div className="text-sm text-gray-600 bg-green-50 border border-green-200 px-4 py-2 rounded-lg">
            🌐 <span className="font-semibold">{totalUsers}</span> users available to connect with
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        {/* Sidebar */}
        <div className="w-80 hidden lg:block">
          <Card className="p-4">
            <h1 className="text-2xl mb-4">Friends</h1>
            <nav className="space-y-2">
              <button className="flex items-center gap-3 w-full p-3 bg-blue-50 text-blue-600 rounded-lg">
                <UsersIcon className="h-5 w-5" />
                All Friends
              </button>
            </nav>
          </Card>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">Friends ({friendsList.length})</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {friendsList.length === 0 ? (
              <Card className="col-span-full p-8 text-center">
                <p className="text-gray-500 mb-4">You haven't added any friends yet</p>
                <Button onClick={() => setShowSearchDialog(true)}>
                  <Search className="h-4 w-4 mr-2" />
                  Find Friends
                </Button>
              </Card>
            ) : (
              friendsList.map((user) => (
                <Card key={user.id} className="p-4">
                  <div className="flex flex-col items-center text-center">
                    <Avatar className="h-24 w-24 mb-3">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback>{user.name[0]}</AvatarFallback>
                    </Avatar>
                    <h3 className="font-semibold mb-1">{user.name}</h3>
                    <p className="text-sm text-gray-500 mb-4">{user.email}</p>
                    <div className="flex gap-2 w-full">
                      <Button variant="secondary" className="flex-1" onClick={() => handleMessage(user)}>
                        Message
                      </Button>
                      <Button variant="outline" className="flex-1" onClick={() => handleUnfriend(user.id, user.name)}>
                        Unfriend
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>

      {activeChat && (
        <Messenger
          recipientId={activeChat.id}
          recipientName={activeChat.name}
          recipientAvatar={activeChat.avatar}
          onClose={() => setActiveChat(null)}
        />
      )}

      <SearchAccountsDialog
        isOpen={showSearchDialog}
        onClose={() => {
          setShowSearchDialog(false);
          loadFriends();
        }}
      />
    </div>
  );
}