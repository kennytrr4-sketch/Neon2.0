import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router';
import { Card } from '../components/ui/card';
import { ScrollArea } from '../components/ui/scroll-area';
import { Clock, Mail, User, Shield } from 'lucide-react';
import { toast } from 'sonner';

interface LoginRecord {
  email: string;
  name: string;
  userId: string;
  timestamp: string;
  date: string;
  isAdmin?: boolean;
}

export function LoginHistoryPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loginHistory, setLoginHistory] = useState<LoginRecord[]>([]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadLoginHistory();
  }, [user, navigate]);

  const loadLoginHistory = () => {
    const history = JSON.parse(localStorage.getItem('loginHistory') || '[]');
    
    // If not admin, filter to show only current user's login history
    const filteredHistory = user?.isAdmin 
      ? history 
      : history.filter((record: LoginRecord) => record.userId === user?.id);
    
    // Sort by most recent first
    const sorted = filteredHistory.sort((a: LoginRecord, b: LoginRecord) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    setLoginHistory(sorted);
  };

  // Get unique emails
  const uniqueEmails = Array.from(new Set(loginHistory.map(record => record.email)));

  if (!user) return null;

  return (
    <div className="max-w-6xl mx-auto p-4">
      <Card className="p-6">
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <h2 className="text-2xl">Login Activity</h2>
            {user.isAdmin && (
              <Shield className="h-5 w-5 text-purple-600" />
            )}
          </div>
          <p className="text-sm text-gray-600">
            {user.isAdmin ? (
              <>Total unique users: {uniqueEmails.length} | Total logins: {loginHistory.length}</>
            ) : (
              <>Your login history: {loginHistory.length} login(s)</>
            )}
          </p>
        </div>

        <div className={user.isAdmin ? "grid md:grid-cols-2 gap-6" : ""}>
          {/* Unique Emails - Only show for admins */}
          {user.isAdmin && (
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Unique Emails
              </h3>
              <ScrollArea className="h-[400px] rounded-md border p-4">
                <div className="space-y-2">
                  {uniqueEmails.length === 0 ? (
                    <p className="text-gray-500 text-sm">No login activity yet</p>
                  ) : (
                    uniqueEmails.map((email, index) => (
                      <div key={index} className="p-2 bg-gray-50 rounded text-sm">
                        {email}
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Login History */}
          <div className={!user.isAdmin ? "w-full" : ""}>
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Clock className="h-5 w-5" />
              {user.isAdmin ? 'Recent Logins' : 'Your Recent Logins'}
            </h3>
            <ScrollArea className="h-[400px] rounded-md border p-4">
              <div className="space-y-3">
                {loginHistory.length === 0 ? (
                  <p className="text-gray-500 text-sm">No login activity yet</p>
                ) : (
                  loginHistory.map((record, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded space-y-1">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        <User className="h-4 w-4 text-gray-600" />
                        {record.name}
                        {record.isAdmin && (
                          <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded">Admin</span>
                        )}
                      </div>
                      {user.isAdmin && (
                        <div className="text-xs text-gray-600">{record.email}</div>
                      )}
                      <div className="text-xs text-gray-500">{record.date}</div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        </div>
      </Card>
    </div>
  );
}