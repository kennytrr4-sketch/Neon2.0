import { useState, useRef, useEffect } from "react";
import { useParams } from "react-router";
import { toast } from "sonner";
import { Camera, Edit, MoreHorizontal, MapPin, Calendar, Image as ImageIcon, Globe, UserMinus, UserPlus, Check } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { useAuth } from "../context/AuthContext";
import { useApp } from "../context/AppContext";
import { PostCard } from "../components/PostCard";
import { EditProfileDialog } from "../components/EditProfileDialog";
import { Messenger } from "../components/Messenger";
import { api } from "../utils/api";

export function Profile() {
  const { userId } = useParams();
  const { user: currentUser, updateProfile } = useAuth();
  const { posts, updatePost, updateUserInPosts } = useApp();
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [activeChat, setActiveChat] = useState<{ id: string; name: string; avatar: string } | null>(null);
  const [viewedUser, setViewedUser] = useState<any>(null);
  const [friendStatus, setFriendStatus] = useState<'none' | 'pending' | 'friends'>('none');
  const [friends, setFriends] = useState<any[]>([]);
  const coverInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  if (!currentUser) return null;

  // Determine which user to display
  const isOwnProfile = !userId || userId === currentUser.id;
  const user = isOwnProfile ? currentUser : viewedUser;

  // Fetch user data when userId changes
  useEffect(() => {
    if (userId && userId !== currentUser.id) {
      // Fetch user from API
      fetchUser(userId);
    } else {
      setViewedUser(null);
      setFriendStatus('none');
    }
  }, [userId, currentUser.id]);

  const fetchUser = async (targetUserId: string) => {
    try {
      const data = await api.getUser(targetUserId);
      if (data.user) {
        setViewedUser(data.user);
        checkFriendStatus(targetUserId);
      } else {
        setViewedUser(null);
      }
    } catch (error) {
      console.error('Error fetching user:', error);
      setViewedUser(null);
    }
  };

  // Load friends for display
  useEffect(() => {
    if (user) {
      loadUserFriends(user.id);
    }
  }, [user?.id]);

  const loadUserFriends = async (targetUserId: string) => {
    try {
      const data = await api.getFriends(targetUserId);
      if (data.friends) {
        setFriends(data.friends);
      }
    } catch (error) {
      console.error('Error loading friends:', error);
    }
  };

  const checkFriendStatus = async (targetUserId: string) => {
    if (!currentUser) return;

    try {
      // Check if already friends
      const data = await api.getFriends(currentUser.id);
      if (data.friends) {
        const isFriend = data.friends.some((f: any) => f.id === targetUserId);
        if (isFriend) {
          setFriendStatus('friends');
          return;
        }
      }
      setFriendStatus('none');
    } catch (error) {
      console.error('Error checking friend status:', error);
      setFriendStatus('none');
    }
  };

  // If viewing another user's profile and user not found or still loading
  if (!isOwnProfile && !viewedUser) {
    return (
      <div className="max-w-5xl mx-auto p-8">
        <Card className="p-8 text-center">
          <p className="text-gray-500">Loading...</p>
        </Card>
      </div>
    );
  }

  // Safety check to ensure user exists before accessing properties
  if (!user) {
    return (
      <div className="max-w-5xl mx-auto p-8">
        <Card className="p-8 text-center">
          <p className="text-gray-500">User not found</p>
        </Card>
      </div>
    );
  }

  // Filter posts by this user
  const userPosts = posts.filter(post => post.userId === user.id);

  const handleLike = (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      updatePost(postId, {
        likes: post.likedByUser ? post.likes - 1 : post.likes + 1,
        likedByUser: !post.likedByUser,
      });
    }
  };

  const handleComment = (postId: string, content: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      updatePost(postId, {
        comments: [
          ...post.comments,
          {
            id: `c${Date.now()}`,
            userId: currentUser.id,
            userName: currentUser.name,
            userAvatar: currentUser.avatar,
            content,
            timestamp: "Just now",
            likes: 0,
          },
        ],
      });
    }
  };

  const handleShare = (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      updatePost(postId, {
        shares: post.shares + 1,
      });
    }
  };

  const handleEditCover = () => {
    coverInputRef.current?.click();
  };

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateProfile({ coverPhoto: reader.result as string });
        toast.success("Cover photo updated!");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditAvatar = () => {
    avatarInputRef.current?.click();
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newAvatar = reader.result as string;
        updateProfile({ avatar: newAvatar });
        updateUserInPosts(currentUser.id, currentUser.name, newAvatar);
        toast.success("Profile picture updated!");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddFriend = async () => {
    if (!currentUser || !user || friendStatus !== 'none') return;

    try {
      const data = await api.addFriend(currentUser.id, user.id);
      if (data.success) {
        setFriendStatus('friends');
        loadUserFriends(user.id);
        toast.success(`You are now friends with ${user.name}`);
      }
    } catch (error) {
      console.error('Error adding friend:', error);
      toast.error('Failed to add friend');
    }
  };

  const handleUnfriend = async () => {
    if (!currentUser || !user || friendStatus !== 'friends') return;

    try {
      await api.removeFriend(currentUser.id, user.id);
      setFriendStatus('none');
      loadUserFriends(user.id);
      toast.info(`Unfriended ${user.name}`);
    } catch (error) {
      console.error('Failed to unfriend:', error);
      toast.error('Failed to unfriend user');
    }
  };

  const handleMessage = () => {
    setActiveChat({ id: user.id, name: user.name, avatar: user.avatar || "" });
  };

  const handleMoreOptions = () => {
    toast.info("Profile options menu");
  };

  const handleSaveProfile = (data: any) => {
    updateProfile(data);
    
    // Update user info in all their posts
    if (data.name || data.avatar) {
      const updatedName = data.name || currentUser.name;
      const updatedAvatar = data.avatar || currentUser.avatar;
      updateUserInPosts(currentUser.id, updatedName, updatedAvatar);
    }
    
    toast.success("Profile updated successfully!");
    setShowEditDialog(false);
  };

  const editProfileRef = useRef(null);
  const messengerRef = useRef(null);

  const renderFriendButton = () => {
    if (friendStatus === 'friends') {
      return (
        <Button onClick={handleUnfriend} variant="secondary">
          <UserMinus className="h-4 w-4 mr-2" />
          Unfriend
        </Button>
      );
    } else if (friendStatus === 'pending') {
      return (
        <Button disabled variant="secondary">
          <Check className="h-4 w-4 mr-2" />
          Request Sent
        </Button>
      );
    } else {
      return (
        <Button onClick={handleAddFriend}>
          <UserPlus className="h-4 w-4 mr-2" />
          Add Friend
        </Button>
      );
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Cover Photo */}
      <div className="relative h-96 bg-gray-300">
        {user.coverPhoto && (
          <img
            src={user.coverPhoto}
            alt="Cover"
            className="w-full h-full object-cover"
          />
        )}
        {isOwnProfile && (
          <Button
            variant="secondary"
            className="absolute bottom-4 right-4"
            onClick={handleEditCover}
          >
            <Camera className="h-4 w-4 mr-2" />
            Edit cover photo
          </Button>
        )}
        <input
          type="file"
          ref={coverInputRef}
          className="hidden"
          onChange={handleCoverChange}
        />
      </div>

      {/* Profile Info */}
      <div className="bg-white border-b">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-end justify-between pb-4">
            <div className="flex gap-6 items-end -mt-8">
              <div className="relative">
                <Avatar className="h-40 w-40 border-4 border-white">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
                {isOwnProfile && (
                  <button className="absolute bottom-2 right-2 bg-gray-200 p-2 rounded-full hover:bg-gray-300" onClick={handleEditAvatar}>
                    <Camera className="h-5 w-5" />
                  </button>
                )}
              </div>
              <div className="mb-4">
                <h1 className="text-3xl">{user.name}</h1>
                <p className="text-gray-600">{friends.length} friends</p>
              </div>
            </div>
            <div className="flex gap-2 mb-4">
              {isOwnProfile ? (
                <>
                  <Button onClick={() => setShowEditDialog(true)}>
                    <Edit className="h-4 w-4 mr-2" />
                    Edit profile
                  </Button>
                </>
              ) : (
                <>
                  {renderFriendButton()}
                  <Button variant="secondary" onClick={handleMessage}>Message</Button>
                </>
              )}
              <Button variant="secondary" size="icon" onClick={handleMoreOptions}>
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Profile Navigation */}
          <Tabs defaultValue="posts" className="w-full">
            <TabsList className="w-full justify-start bg-transparent border-t">
              <TabsTrigger value="posts" className="px-6">
                Posts
              </TabsTrigger>
              <TabsTrigger value="about" className="px-6">
                About
              </TabsTrigger>
              <TabsTrigger value="friends" className="px-6">
                Friends
              </TabsTrigger>
              <TabsTrigger value="photos" className="px-6">
                Photos
              </TabsTrigger>
              <TabsTrigger value="videos" className="px-6">
                Videos
              </TabsTrigger>
            </TabsList>

            <div className="p-4 bg-gray-100 min-h-screen">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Left Column - Intro */}
                <div className="lg:col-span-1 space-y-4">
                  <Card className="p-4">
                    <h2 className="text-xl mb-4">Intro</h2>
                    {user.bio && (
                      <p className="text-center mb-4">{user.bio}</p>
                    )}
                    {user.location && (
                      <div className="flex items-center gap-2 text-gray-600 mb-2">
                        <MapPin className="h-5 w-5" />
                        <span>Lives in {user.location}</span>
                      </div>
                    )}
                    {user.website && (
                      <div className="flex items-center gap-2 text-gray-600 mb-2">
                        <Globe className="h-5 w-5" />
                        <a href={user.website.startsWith('http') ? user.website : `https://${user.website}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                          {user.website}
                        </a>
                      </div>
                    )}
                    {user.joined && (
                      <div className="flex items-center gap-2 text-gray-600 mb-4">
                        <Calendar className="h-5 w-5" />
                        <span>Joined {user.joined}</span>
                      </div>
                    )}
                    {isOwnProfile && (
                      <Button variant="secondary" className="w-full">
                        Edit details
                      </Button>
                    )}
                  </Card>

                  <Card className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl">Photos</h2>
                      <button className="text-blue-600 hover:underline">
                        See all photos
                      </button>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                        <div key={i} className="aspect-square bg-gray-300 rounded-lg flex items-center justify-center">
                          <ImageIcon className="h-8 w-8 text-gray-500" />
                        </div>
                      ))}
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-xl">Friends</h2>
                      <button className="text-blue-600 hover:underline">
                        See all friends
                      </button>
                    </div>
                    <p className="text-gray-600 mb-4">{friends.length} friends</p>
                    {friends.length > 0 ? (
                      <div className="grid grid-cols-3 gap-2">
                        {friends.slice(0, 9).map((friend) => (
                          <div key={friend.id} className="flex flex-col items-center">
                            <Avatar className="h-16 w-16 mb-1">
                              <AvatarImage src={friend.avatar} alt={friend.name} />
                              <AvatarFallback>{friend.name[0]}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-center truncate w-full">{friend.name}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center text-gray-500 py-4">
                        <p>No friends yet</p>
                      </div>
                    )}
                  </Card>
                </div>

                {/* Right Column - Posts */}
                <TabsContent value="posts" className="lg:col-span-2 mt-0">
                  <div className="space-y-4">
                    {userPosts.length > 0 ? (
                      userPosts.map((post) => (
                        <PostCard
                          key={post.id}
                          post={post}
                          onLike={handleLike}
                          onComment={handleComment}
                          onShare={handleShare}
                        />
                      ))
                    ) : (
                      <Card className="p-8 text-center">
                        <p className="text-gray-500">No posts yet</p>
                      </Card>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="about" className="lg:col-span-2 mt-0">
                  <Card className="p-6">
                    <h2 className="text-2xl mb-4">About</h2>
                    <div className="space-y-4">
                      {user.bio && (
                        <div>
                          <h3 className="font-semibold mb-2">Bio</h3>
                          <p>{user.bio}</p>
                        </div>
                      )}
                      {user.location && (
                        <div>
                          <h3 className="font-semibold mb-2">Location</h3>
                          <p>{user.location}</p>
                        </div>
                      )}
                      {user.website && (
                        <div>
                          <h3 className="font-semibold mb-2">Website</h3>
                          <a href={user.website.startsWith('http') ? user.website : `https://${user.website}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                            {user.website}
                          </a>
                        </div>
                      )}
                    </div>
                  </Card>
                </TabsContent>

                <TabsContent value="friends" className="lg:col-span-2 mt-0">
                  <Card className="p-6">
                    <h2 className="text-2xl mb-4">Friends ({friends.length})</h2>
                    {friends.length > 0 ? (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {friends.map((friend) => (
                          <div key={friend.id} className="flex flex-col items-center p-4 rounded-lg hover:bg-gray-50">
                            <Avatar className="h-24 w-24 mb-2">
                              <AvatarImage src={friend.avatar} alt={friend.name} />
                              <AvatarFallback>{friend.name[0]}</AvatarFallback>
                            </Avatar>
                            <span className="font-semibold text-center">{friend.name}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center text-gray-500 py-12">
                        <p>No friends yet</p>
                      </div>
                    )}
                  </Card>
                </TabsContent>

                <TabsContent value="photos" className="lg:col-span-2 mt-0">
                  <Card className="p-6">
                    <h2 className="text-2xl mb-4">Photos</h2>
                    <div className="grid grid-cols-3 gap-2">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => (
                        <div key={i} className="aspect-square bg-gray-300 rounded-lg flex items-center justify-center">
                          <ImageIcon className="h-12 w-12 text-gray-500" />
                        </div>
                      ))}
                    </div>
                  </Card>
                </TabsContent>

                <TabsContent value="videos" className="lg:col-span-2 mt-0">
                  <Card className="p-6">
                    <h2 className="text-2xl mb-4">Videos</h2>
                    <p className="text-gray-500 text-center py-12">No videos to show</p>
                  </Card>
                </TabsContent>
              </div>
            </div>
          </Tabs>
        </div>
      </div>

      {showEditDialog && (
        <EditProfileDialog
          onClose={() => setShowEditDialog(false)}
          onSave={handleSaveProfile}
        />
      )}
      
      {activeChat && (
        <Messenger
          recipientId={activeChat.id}
          recipientName={activeChat.name}
          recipientAvatar={activeChat.avatar}
          onClose={() => setActiveChat(null)}
        />
      )}
      
      <input
        type="file"
        accept="image/*"
        ref={avatarInputRef}
        className="hidden"
        onChange={handleAvatarChange}
      />
    </div>
  );
}