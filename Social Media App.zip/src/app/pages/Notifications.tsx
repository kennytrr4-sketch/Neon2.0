import { ThumbsUp, MessageCircle, UserPlus, Share2, Settings, Bell } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Notification } from "../types";
import { toast } from "sonner";
import { useApp } from "../context/AppContext";

export function Notifications() {
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead } = useApp();

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleSettings = () => {
    toast.info("Notification settings");
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl">Notifications</h1>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={markAllNotificationsAsRead}>
              Mark all as read
            </Button>
            <Button variant="ghost" size="icon" onClick={handleSettings}>
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="all">
              All {unreadCount > 0 && `(${unreadCount})`}
            </TabsTrigger>
            <TabsTrigger value="unread">Unread</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-2">
            {notifications.map((notif) => (
              <NotificationItem
                key={notif.id}
                notification={notif}
                onMarkAsRead={markNotificationAsRead}
              />
            ))}
          </TabsContent>

          <TabsContent value="unread" className="space-y-2">
            {notifications.filter((n) => !n.read).length > 0 ? (
              notifications
                .filter((n) => !n.read)
                .map((notif) => (
                  <NotificationItem
                    key={notif.id}
                    notification={notif}
                    onMarkAsRead={markNotificationAsRead}
                  />
                ))
            ) : (
              <div className="text-center py-12">
                <Bell className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No unread notifications</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

interface NotificationItemProps {
  notification: Notification;
  onMarkAsRead: (id: string) => void;
}

function NotificationItem({ notification, onMarkAsRead }: NotificationItemProps) {
  const getIcon = (type: Notification["type"]) => {
    switch (type) {
      case "like":
        return (
          <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-1">
            <ThumbsUp className="h-3 w-3 text-white fill-white" />
          </div>
        );
      case "comment":
        return (
          <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-1">
            <MessageCircle className="h-3 w-3 text-white" />
          </div>
        );
      case "friend":
        return (
          <div className="absolute -bottom-1 -right-1 bg-purple-500 rounded-full p-1">
            <UserPlus className="h-3 w-3 text-white" />
          </div>
        );
      case "share":
        return (
          <div className="absolute -bottom-1 -right-1 bg-orange-500 rounded-full p-1">
            <Share2 className="h-3 w-3 text-white" />
          </div>
        );
    }
  };

  return (
    <div
      className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
        !notification.read ? "bg-blue-50 hover:bg-blue-100" : "hover:bg-gray-100"
      }`}
      onClick={() => !notification.read && onMarkAsRead(notification.id)}
    >
      <div className="relative">
        <Avatar>
          <AvatarImage src={notification.userAvatar} alt={notification.userName} />
          <AvatarFallback>{notification.userName[0]}</AvatarFallback>
        </Avatar>
        {getIcon(notification.type)}
      </div>
      <div className="flex-1">
        <p>
          <span className="font-semibold">{notification.userName}</span>{" "}
          {notification.content}
        </p>
        <p className="text-sm text-blue-600">{notification.timestamp}</p>
      </div>
      {!notification.read && (
        <div className="h-3 w-3 bg-blue-600 rounded-full flex-shrink-0 mt-2" />
      )}
    </div>
  );
}