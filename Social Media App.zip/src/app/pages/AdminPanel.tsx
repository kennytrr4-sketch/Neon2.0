import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Shield, Ban, CheckCircle, Trash2, Edit, Users, Activity, Search, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

interface Account {
  id: string;
  email: string;
  password: string;
  name: string;
  avatar: string;
  bio: string;
  location: string;
  website: string;
  joined: string;
  friends: number;
  isAdmin: boolean;
  isBanned: boolean;
}

interface LoginRecord {
  email: string;
  name: string;
  userId: string;
  timestamp: string;
  date: string;
  isAdmin?: boolean;
}

export function AdminPanel() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loginHistory, setLoginHistory] = useState<LoginRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [showPasswordsMap, setShowPasswordsMap] = useState<{ [key: string]: boolean }>({});
  const [editForm, setEditForm] = useState({
    name: '',
    email: '',
    bio: '',
    location: '',
    website: '',
  });

  // Redirect if not admin
  useEffect(() => {
    if (!user?.isAdmin) {
      navigate('/');
      toast.error('Access denied. Admin privileges required.');
    }
  }, [user, navigate]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    setAccounts(mockAccounts);

    const history = JSON.parse(localStorage.getItem('loginHistory') || '[]');
    setLoginHistory(history.reverse()); // Most recent first
  };

  const handleBanUser = (userId: string) => {
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    const updatedAccounts = mockAccounts.map((acc: Account) =>
      acc.id === userId ? { ...acc, isBanned: !acc.isBanned } : acc
    );
    localStorage.setItem('mockAccounts', JSON.stringify(updatedAccounts));
    setAccounts(updatedAccounts);
    
    const account = updatedAccounts.find((acc: Account) => acc.id === userId);
    toast.success(account?.isBanned ? 'User banned successfully' : 'User unbanned successfully');
  };

  const handleDeleteAccount = (userId: string) => {
    if (userId === 'admin-staff') {
      toast.error('Cannot delete admin account');
      return;
    }

    if (!confirm('Are you sure you want to delete this account? This action cannot be undone.')) {
      return;
    }

    // Delete from accounts
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    const updatedAccounts = mockAccounts.filter((acc: Account) => acc.id !== userId);
    localStorage.setItem('mockAccounts', JSON.stringify(updatedAccounts));
    setAccounts(updatedAccounts);

    // Clean up related data
    // Remove posts
    const posts = JSON.parse(localStorage.getItem('posts') || '[]');
    const updatedPosts = posts.filter((p: any) => p.userId !== userId);
    localStorage.setItem('posts', JSON.stringify(updatedPosts));

    // Remove notifications
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const updatedNotifications = notifications.filter((n: any) => n.userId !== userId);
    localStorage.setItem('notifications', JSON.stringify(updatedNotifications));

    // Remove friend requests
    const friendRequests = JSON.parse(localStorage.getItem('friendRequests') || '{}');
    delete friendRequests[userId];
    Object.keys(friendRequests).forEach(key => {
      friendRequests[key] = friendRequests[key].filter((id: string) => id !== userId);
    });
    localStorage.setItem('friendRequests', JSON.stringify(friendRequests));

    toast.success('Account deleted successfully');
  };

  const openEditDialog = (account: Account) => {
    setEditingAccount(account);
    setEditForm({
      name: account.name,
      email: account.email,
      bio: account.bio || '',
      location: account.location || '',
      website: account.website || '',
    });
  };

  const handleSaveEdit = () => {
    if (!editingAccount) return;

    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    const updatedAccounts = mockAccounts.map((acc: Account) =>
      acc.id === editingAccount.id ? { ...acc, ...editForm } : acc
    );
    localStorage.setItem('mockAccounts', JSON.stringify(updatedAccounts));
    setAccounts(updatedAccounts);
    setEditingAccount(null);
    toast.success('Account updated successfully');
  };

  const clearLoginHistory = () => {
    if (!confirm('Are you sure you want to clear all login history?')) {
      return;
    }
    localStorage.setItem('loginHistory', JSON.stringify([]));
    setLoginHistory([]);
    toast.success('Login history cleared');
  };

  const togglePasswordVisibility = (accountId: string) => {
    setShowPasswordsMap(prev => ({
      ...prev,
      [accountId]: !prev[accountId]
    }));
  };

  const filteredAccounts = accounts.filter(
    (acc) =>
      acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      acc.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      acc.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    totalUsers: accounts.length,
    bannedUsers: accounts.filter((acc) => acc.isBanned).length,
    activeUsers: accounts.filter((acc) => !acc.isBanned).length,
    totalLogins: loginHistory.length,
  };

  if (!user?.isAdmin) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div
          className="flex items-center justify-center h-12 w-12 rounded-xl"
          style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)',
          }}
        >
          <Shield className="h-7 w-7 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold" style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}>
            Admin Panel
          </h1>
          <p className="text-gray-600">Manage users, monitor activity, and maintain the platform</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-600" />
              <span className="text-2xl font-bold">{stats.totalUsers}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="text-2xl font-bold">{stats.activeUsers}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Banned Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Ban className="h-5 w-5 text-red-600" />
              <span className="text-2xl font-bold">{stats.bannedUsers}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Logins</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-purple-600" />
              <span className="text-2xl font-bold">{stats.totalLogins}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="credentials">Credentials</TabsTrigger>
          <TabsTrigger value="activity">Login Activity</TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>All Users</CardTitle>
                  <CardDescription>Manage user accounts and permissions</CardDescription>
                </div>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    type="search"
                    placeholder="Search users..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredAccounts.map((account) => (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={account.avatar} alt={account.name} />
                        <AvatarFallback>{account.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{account.name}</span>
                          {account.isAdmin && (
                            <Badge className="bg-purple-600">Admin</Badge>
                          )}
                          {account.isBanned && (
                            <Badge variant="destructive">Banned</Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{account.email}</p>
                        <p className="text-xs text-gray-500">ID: {account.id}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(account)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>

                      {!account.isAdmin && (
                        <>
                          <Button
                            variant={account.isBanned ? 'default' : 'destructive'}
                            size="sm"
                            onClick={() => handleBanUser(account.id)}
                          >
                            {account.isBanned ? (
                              <>
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Unban
                              </>
                            ) : (
                              <>
                                <Ban className="h-4 w-4 mr-1" />
                                Ban
                              </>
                            )}
                          </Button>

                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteAccount(account.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                ))}

                {filteredAccounts.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No users found matching your search.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Credentials Tab */}
        <TabsContent value="credentials" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>User Credentials</CardTitle>
                  <CardDescription>View account login credentials for support purposes</CardDescription>
                </div>
                <Badge variant="outline" className="text-yellow-700 border-yellow-700">
                  Sensitive Information
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {accounts.map((account) => (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={account.avatar} alt={account.name} />
                        <AvatarFallback>{account.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{account.name}</span>
                          {account.isAdmin && (
                            <Badge className="bg-purple-600 text-xs">Admin</Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{account.email}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-gray-500">Password:</span>
                          <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">
                            {showPasswordsMap[account.id] ? account.password : '••••••••'}
                          </code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => togglePasswordVisibility(account.id)}
                            className="h-6 w-6 p-0"
                          >
                            {showPasswordsMap[account.id] ? (
                              <EyeOff className="h-3 w-3" />
                            ) : (
                              <Eye className="h-3 w-3" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              navigator.clipboard.writeText(account.password);
                              toast.success('Password copied to clipboard');
                            }}
                            className="h-6 px-2 text-xs"
                          >
                            Copy
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {accounts.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No accounts found.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Login Activity</CardTitle>
                  <CardDescription>Monitor user login history and activity</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={clearLoginHistory}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear History
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {loginHistory.map((record, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Activity className="h-5 w-5 text-gray-400" />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{record.name}</span>
                          {record.isAdmin && (
                            <Badge className="bg-purple-600 text-xs">Admin</Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{record.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">{record.date}</p>
                      <p className="text-xs text-gray-500">User ID: {record.userId}</p>
                    </div>
                  </div>
                ))}

                {loginHistory.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No login activity recorded yet.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Edit User Dialog */}
      <Dialog open={!!editingAccount} onOpenChange={() => setEditingAccount(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User Account</DialogTitle>
            <DialogDescription>
              Make changes to the user's account information
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                type="email"
                value={editForm.email}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-bio">Bio</Label>
              <Input
                id="edit-bio"
                value={editForm.bio}
                onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-location">Location</Label>
              <Input
                id="edit-location"
                value={editForm.location}
                onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-website">Website</Label>
              <Input
                id="edit-website"
                value={editForm.website}
                onChange={(e) => setEditForm({ ...editForm, website: e.target.value })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingAccount(null)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}