import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Eye, EyeOff, Zap, Check, X } from 'lucide-react';

export function Login() {
  const [isSignup, setIsSignup] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login, signup, isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  // Password strength checker
  const checkPasswordStrength = (pwd: string) => {
    const checks = {
      length: pwd.length >= 8,
      uppercase: /[A-Z]/.test(pwd),
      lowercase: /[a-z]/.test(pwd),
      number: /[0-9]/.test(pwd),
      special: /[!@#$%^&*(),.?":{}|<>]/.test(pwd),
    };
    return checks;
  };

  const passwordChecks = checkPasswordStrength(password);
  const isPasswordStrong = Object.values(passwordChecks).every(check => check);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isSignup) {
      if (!name || !email || !password) {
        setError('Please fill in all fields');
        return;
      }
      if (!isPasswordStrong) {
        setError('Password does not meet all requirements');
        return;
      }
      const success = await signup(name, email, password);
      if (success) {
        navigate('/');
      } else {
        setError('Email already exists');
      }
    } else {
      if (!email || !password) {
        setError('Please fill in all fields');
        return;
      }
      const success = await login(email, password);
      if (success) {
        navigate('/');
      } else {
        // Check if account is banned
        const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
        const account = mockAccounts.find((acc: any) => acc.email === email);
        if (account && account.isBanned) {
          setError('Your account has been banned. Please contact support.');
        } else {
          setError('Invalid email or password');
        }
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
    }}>
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-xl text-white mb-4" style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            boxShadow: '0 8px 24px rgba(102, 126, 234, 0.4)'
          }}>
            <Zap className="h-10 w-10 fill-white" />
          </div>
          <h1 className="text-4xl mb-2" style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}>
            Neon
          </h1>
          <h2 className="text-2xl mb-2">
            {isSignup ? 'Create Account' : 'Welcome Back'}
          </h2>
          <p className="text-gray-600">
            {isSignup ? 'Join the community today' : 'Login to continue'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignup && (
            <div>
              <label htmlFor="name" className="block text-sm mb-2 text-gray-700">
                Full Name
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
                placeholder="John Doe"
              />
            </div>
          )}

          <div>
            <label htmlFor="email" className="block text-sm mb-2 text-gray-700">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
              placeholder="you@example.com"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm mb-2 text-gray-700">
              Password
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
            {isSignup ? 'Sign Up' : 'Login'}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={() => {
              setIsSignup(!isSignup);
              setError('');
              setPassword('');
            }}
            className="text-purple-600 hover:text-purple-700 hover:underline"
          >
            {isSignup ? 'Already have an account? Login' : "Don't have an account? Sign Up"}
          </button>
        </div>

        {isSignup && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <p className="text-sm font-semibold mb-2">Password Requirements:</p>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs">
                {passwordChecks.length ? (
                  <Check className="h-4 w-4 text-green-600" />
                ) : (
                  <X className="h-4 w-4 text-red-600" />
                )}
                <span className={passwordChecks.length ? 'text-green-600' : 'text-red-600'}>
                  At least 8 characters
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                {passwordChecks.uppercase ? (
                  <Check className="h-4 w-4 text-green-600" />
                ) : (
                  <X className="h-4 w-4 text-red-600" />
                )}
                <span className={passwordChecks.uppercase ? 'text-green-600' : 'text-red-600'}>
                  One uppercase letter
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                {passwordChecks.lowercase ? (
                  <Check className="h-4 w-4 text-green-600" />
                ) : (
                  <X className="h-4 w-4 text-red-600" />
                )}
                <span className={passwordChecks.lowercase ? 'text-green-600' : 'text-red-600'}>
                  One lowercase letter
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                {passwordChecks.number ? (
                  <Check className="h-4 w-4 text-green-600" />
                ) : (
                  <X className="h-4 w-4 text-red-600" />
                )}
                <span className={passwordChecks.number ? 'text-green-600' : 'text-red-600'}>
                  One number
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                {passwordChecks.special ? (
                  <Check className="h-4 w-4 text-green-600" />
                ) : (
                  <X className="h-4 w-4 text-red-600" />
                )}
                <span className={passwordChecks.special ? 'text-green-600' : 'text-red-600'}>
                  One special character (!@#$%^&*)
                </span>
              </div>
            </div>
          </div>
        )}

        {!isSignup && (
          <>
            <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm font-medium text-blue-900 mb-2">Demo Account:</p>
              <p className="text-xs text-blue-700">Email: demo@example.com</p>
              <p className="text-xs text-blue-700">Password: Demo123!</p>
              <button
                type="button"
                onClick={async () => {
                  const success = await login('demo@example.com', 'Demo123!');
                  if (success) navigate('/');
                }}
                className="mt-2 text-xs text-blue-600 hover:text-blue-800 hover:underline font-medium"
              >
                Quick Login with Demo
              </button>
            </div>

            <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm font-medium text-green-900 mb-2">🌐 Mock Cross-Device Accounts:</p>
              <p className="text-xs text-green-700 mb-2">
                12+ pre-loaded users simulate accounts from other devices. Search for friends like:
              </p>
              <div className="space-y-1">
                <p className="text-xs text-green-600">• Sarah Johnson - sarah.johnson@email.com</p>
                <p className="text-xs text-green-600">• Mike Chen - mike.chen@email.com</p>
                <p className="text-xs text-green-600">• Emily Rodriguez - emily.rodriguez@email.com</p>
              </div>
              <p className="text-xs text-green-700 mt-2 italic">
                New mock users join automatically every 2-3 minutes!
              </p>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}