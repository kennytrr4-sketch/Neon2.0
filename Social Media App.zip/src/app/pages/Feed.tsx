import { useState, useEffect } from "react";
import { CreatePost } from "../components/CreatePost";
import { PostCard } from "../components/PostCard";
import { Stories } from "../components/Stories";
import { Sidebar } from "../components/Sidebar";
import { RightSidebar } from "../components/RightSidebar";
import { stories } from "../data/mockData";
import { useAuth } from "../context/AuthContext";
import { useApp } from "../context/AppContext";
import { Post } from "../types";
import { api } from "../utils/api";

export function Feed() {
  const { user: currentUser } = useAuth();
  const { posts, addPost, updatePost } = useApp();
  const [friendIds, setFriendIds] = useState<string[]>([]);

  useEffect(() => {
    if (currentUser) {
      loadFriends();
    }
  }, [currentUser]);

  const loadFriends = async () => {
    if (!currentUser) return;

    try {
      const data = await api.getFriends(currentUser.id);
      if (data.friends) {
        setFriendIds(data.friends.map((f: any) => f.id));
      }
    } catch (error) {
      console.error('Failed to load friends:', error);
    }
  };

  if (!currentUser) return null;

  // Filter posts to show only from current user or friends
  const filteredPosts = posts.filter(post =>
    post.userId === currentUser.id || friendIds.includes(post.userId)
  );

  const handleCreatePost = (content: string, image?: string) => {
    const newPost: Post = {
      id: `p${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.name}`,
      content,
      timestamp: "Just now",
      likes: 0,
      comments: [],
      shares: 0,
      image,
    };
    addPost(newPost);
  };

  const handleLike = (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      updatePost(postId, {
        likes: post.likedByUser ? post.likes - 1 : post.likes + 1,
        likedByUser: !post.likedByUser,
      });
    }
  };

  const handleComment = (postId: string, content: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      updatePost(postId, {
        comments: [
          ...post.comments,
          {
            id: `c${Date.now()}`,
            userId: currentUser!.id,
            userName: currentUser!.name,
            userAvatar: currentUser!.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser!.name}`,
            content,
            timestamp: "Just now",
            likes: 0,
          },
        ],
      });
    }
  };

  const handleShare = (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      updatePost(postId, {
        shares: post.shares + 1,
      });
    }
  };

  return (
    <div className="flex max-w-[1920px] mx-auto">
      <Sidebar />

      <div className="flex-1 max-w-2xl mx-auto p-4">
        <Stories stories={stories} />
        <CreatePost onPost={handleCreatePost} />

        {filteredPosts.length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center shadow">
            <p className="text-gray-500 mb-2">No posts to show</p>
            <p className="text-sm text-gray-400">
              Add friends to see their posts in your feed!
            </p>
          </div>
        ) : (
          filteredPosts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onLike={handleLike}
              onComment={handleComment}
              onShare={handleShare}
            />
          ))
        )}
      </div>

      <RightSidebar />
    </div>
  );
}