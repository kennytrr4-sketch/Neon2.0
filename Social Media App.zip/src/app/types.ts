export interface User {
  id: string;
  name: string;
  avatar: string;
  coverPhoto?: string;
  bio?: string;
  location?: string;
  joined?: string;
  friends?: number;
  photos?: number;
  isAdmin?: boolean;
  isBanned?: boolean;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  image?: string;
  timestamp: string;
  likes: number;
  comments: Comment[];
  shares: number;
  likedByUser?: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  timestamp: string;
  likes: number;
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'friend' | 'share';
  userName: string;
  userAvatar: string;
  content: string;
  timestamp: string;
  read: boolean;
  postId?: string;
}

export interface Story {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  image: string;
  timestamp: string;
}