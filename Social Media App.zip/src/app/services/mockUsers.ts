// Mock users that simulate accounts created on other devices
export const mockUsersFromOtherDevices = [
  {
    id: 'user-device-001',
    email: 'sarah.johnson@email.com',
    password: 'Sarah123!',
    name: 'Sarah Johnson',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah',
    bio: 'Coffee enthusiast ☕ | Travel blogger | Living life one adventure at a time 🌍',
    location: 'San Francisco, CA',
    website: 'https://sarahtravels.com',
    coverPhoto: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&h=400&fit=crop',
    joined: 'March 2024',
    friends: 234,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-002',
    email: 'mike.chen@email.com',
    password: 'Mike123!',
    name: 'Mike Chen',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike',
    bio: 'Tech enthusiast | Gamer 🎮 | Building cool stuff with code',
    location: 'Seattle, WA',
    website: '',
    coverPhoto: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1200&h=400&fit=crop',
    joined: 'February 2024',
    friends: 156,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-003',
    email: 'emily.rodriguez@email.com',
    password: 'Emily123!',
    name: 'Emily Rodriguez',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=emily',
    bio: 'Fitness coach 💪 | Nutrition expert | Helping people live healthier lives',
    location: 'Miami, FL',
    website: 'https://emilyfit.com',
    coverPhoto: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1200&h=400&fit=crop',
    joined: 'January 2024',
    friends: 445,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-004',
    email: 'james.wilson@email.com',
    password: 'James123!',
    name: 'James Wilson',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=james',
    bio: 'Photographer 📸 | Nature lover | Capturing moments that matter',
    location: 'Portland, OR',
    website: 'https://jwilsonphoto.com',
    coverPhoto: 'https://images.unsplash.com/photo-1511884642898-4c92249e20b6?w=1200&h=400&fit=crop',
    joined: 'March 2024',
    friends: 312,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-005',
    email: 'alex.martinez@email.com',
    password: 'Alex123!',
    name: 'Alex Martinez',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex',
    bio: 'Digital artist 🎨 | NFT creator | Making art in the metaverse',
    location: 'Austin, TX',
    website: 'https://alexart.io',
    coverPhoto: 'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=1200&h=400&fit=crop',
    joined: 'February 2024',
    friends: 567,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-006',
    email: 'lisa.thompson@email.com',
    password: 'Lisa123!',
    name: 'Lisa Thompson',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=lisa',
    bio: 'Chef 👩‍🍳 | Food blogger | Sharing recipes and culinary adventures',
    location: 'New York, NY',
    website: 'https://lisacooks.com',
    coverPhoto: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200&h=400&fit=crop',
    joined: 'January 2024',
    friends: 689,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-007',
    email: 'david.park@email.com',
    password: 'David123!',
    name: 'David Park',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=david',
    bio: 'Music producer 🎵 | DJ | Creating beats and vibes',
    location: 'Los Angeles, CA',
    website: 'https://davidparkmusic.com',
    coverPhoto: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200&h=400&fit=crop',
    joined: 'March 2024',
    friends: 423,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-008',
    email: 'rachel.kim@email.com',
    password: 'Rachel123!',
    name: 'Rachel Kim',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=rachel',
    bio: 'Fashion designer ✨ | Sustainable fashion advocate | Style is what you make it',
    location: 'Chicago, IL',
    website: 'https://rachelkimfashion.com',
    coverPhoto: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&h=400&fit=crop',
    joined: 'February 2024',
    friends: 834,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-009',
    email: 'chris.anderson@email.com',
    password: 'Chris123!',
    name: 'Chris Anderson',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=chris',
    bio: 'Software engineer 💻 | Open source contributor | Building the future',
    location: 'Boston, MA',
    website: 'https://github.com/chrisanderson',
    coverPhoto: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&h=400&fit=crop',
    joined: 'January 2024',
    friends: 298,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-010',
    email: 'jessica.lee@email.com',
    password: 'Jessica123!',
    name: 'Jessica Lee',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=jessica',
    bio: 'Yoga instructor 🧘‍♀️ | Wellness coach | Finding peace in every pose',
    location: 'Denver, CO',
    website: 'https://jessicayoga.com',
    coverPhoto: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1200&h=400&fit=crop',
    joined: 'March 2024',
    friends: 521,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-011',
    email: 'tom.garcia@email.com',
    password: 'Tom123!',
    name: 'Tom Garcia',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=tom',
    bio: 'Marketing strategist 📊 | Helping brands grow | Data-driven decisions',
    location: 'Dallas, TX',
    website: '',
    coverPhoto: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=400&fit=crop',
    joined: 'February 2024',
    friends: 367,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  },
  {
    id: 'user-device-012',
    email: 'maya.patel@email.com',
    password: 'Maya123!',
    name: 'Maya Patel',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=maya',
    bio: 'Entrepreneur 🚀 | Startup founder | Changing the world one idea at a time',
    location: 'San Diego, CA',
    website: 'https://mayapatel.com',
    coverPhoto: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=1200&h=400&fit=crop',
    joined: 'January 2024',
    friends: 756,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  }
];

// Function to simulate new users joining from other devices over time
export function getRandomNewUser(): any {
  const firstNames = ['Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Quinn', 'Avery', 'Blake', 'Cameron', 'Drew'];
  const lastNames = ['Smith', 'Brown', 'Davis', 'Miller', 'Moore', 'Taylor', 'White', 'Harris', 'Clark', 'Lewis'];
  const locations = ['New York, NY', 'Los Angeles, CA', 'Chicago, IL', 'Houston, TX', 'Phoenix, AZ', 'Philadelphia, PA'];
  const bios = [
    'Living my best life ✨',
    'Just here for the memes 😄',
    'Coffee addict ☕',
    'Dog parent 🐕',
    'Adventure seeker 🌄',
    'Bookworm 📚',
    'Fitness junkie 💪',
    'Movie buff 🎬'
  ];

  const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
  const name = `${firstName} ${lastName}`;
  const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}@email.com`;

  return {
    id: `user-device-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    email,
    password: `${firstName}123!`,
    name,
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`,
    bio: bios[Math.floor(Math.random() * bios.length)],
    location: locations[Math.floor(Math.random() * locations.length)],
    website: '',
    coverPhoto: '',
    joined: 'April 2024',
    friends: Math.floor(Math.random() * 300) + 10,
    isAdmin: false,
    isBanned: false,
    fromOtherDevice: true
  };
}
