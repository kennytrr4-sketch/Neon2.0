import { projectId, publicAnonKey } from '../../../utils/supabase/info';

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-3170f0d7`;

export const api = {
  // Users
  async getUsers() {
    // Use localStorage instead of API
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    // Filter out demo user
    const users = mockAccounts
      .filter((acc: any) => acc.id !== 'demo-user')
      .map((acc: any) => ({
        id: acc.id,
        name: acc.name,
        email: acc.email,
        avatar: acc.avatar,
        bio: acc.bio,
        location: acc.location,
        website: acc.website,
        joined: acc.joined,
        friends: acc.friends
      }));
    return { users };
  },

  async getUser(userId: string) {
    // Use localStorage instead of API
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    const account = mockAccounts.find((acc: any) => acc.id === userId);
    if (account) {
      return {
        user: {
          id: account.id,
          name: account.name,
          email: account.email,
          avatar: account.avatar,
          bio: account.bio,
          location: account.location,
          website: account.website,
          joined: account.joined,
          friends: account.friends
        }
      };
    }
    return { user: null };
  },

  // Messages
  async sendMessage(messageData: any) {
    // Use localStorage for messages
    const messages = JSON.parse(localStorage.getItem('messages') || '[]');
    const newMessage = {
      ...messageData,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString()
    };
    messages.push(newMessage);
    localStorage.setItem('messages', JSON.stringify(messages));
    return { success: true, message: newMessage };
  },

  async getMessages(conversationId: string) {
    // Use localStorage for messages
    const messages = JSON.parse(localStorage.getItem('messages') || '[]');
    const conversationMessages = messages.filter((msg: any) => msg.conversationId === conversationId);
    return { messages: conversationMessages };
  },

  // Stories
  async createStory(storyData: any) {
    // Use localStorage for stories
    const stories = JSON.parse(localStorage.getItem('stories') || '[]');
    const newStory = {
      ...storyData,
      id: `story-${Date.now()}`,
      timestamp: new Date().toISOString()
    };
    stories.push(newStory);
    localStorage.setItem('stories', JSON.stringify(stories));
    return { success: true, story: newStory };
  },

  async getStories() {
    // Use localStorage for stories
    const stories = JSON.parse(localStorage.getItem('stories') || '[]');
    // Filter out stories older than 24 hours
    const now = new Date().getTime();
    const validStories = stories.filter((story: any) => {
      const storyTime = new Date(story.timestamp).getTime();
      return (now - storyTime) < 24 * 60 * 60 * 1000;
    });
    // Update localStorage to remove old stories
    localStorage.setItem('stories', JSON.stringify(validStories));
    return { stories: validStories };
  },

  // Friends
  async addFriend(userId: string, friendId: string) {
    // Use localStorage for friends
    const friendships = JSON.parse(localStorage.getItem('friendships') || '[]');
    
    // Check if friendship already exists
    const exists = friendships.some((f: any) => 
      (f.userId === userId && f.friendId === friendId) ||
      (f.userId === friendId && f.friendId === userId)
    );
    
    if (!exists) {
      friendships.push({ userId, friendId, timestamp: new Date().toISOString() });
      localStorage.setItem('friendships', JSON.stringify(friendships));
    }
    
    return { success: true };
  },

  async removeFriend(userId: string, friendId: string) {
    // Use localStorage for friends
    const friendships = JSON.parse(localStorage.getItem('friendships') || '[]');
    const filtered = friendships.filter((f: any) => 
      !((f.userId === userId && f.friendId === friendId) ||
        (f.userId === friendId && f.friendId === userId))
    );
    localStorage.setItem('friendships', JSON.stringify(filtered));
    return { success: true };
  },

  async getFriends(userId: string) {
    // Use localStorage for friends
    const friendships = JSON.parse(localStorage.getItem('friendships') || '[]');
    const mockAccounts = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    
    // Get all friend IDs for this user
    const friendIds = friendships
      .filter((f: any) => f.userId === userId || f.friendId === userId)
      .map((f: any) => f.userId === userId ? f.friendId : f.userId);
    
    // Get friend details
    const friends = mockAccounts
      .filter((acc: any) => friendIds.includes(acc.id))
      .map((acc: any) => ({
        id: acc.id,
        name: acc.name,
        email: acc.email,
        avatar: acc.avatar,
        bio: acc.bio,
        location: acc.location,
        website: acc.website
      }));
    
    return { friends };
  },

  // Calls
  async initiateCall(callData: any) {
    // Use localStorage for calls
    const calls = JSON.parse(localStorage.getItem('calls') || '[]');
    const newCall = {
      ...callData,
      id: `call-${Date.now()}`,
      timestamp: new Date().toISOString()
    };
    calls.push(newCall);
    localStorage.setItem('calls', JSON.stringify(calls));
    return { success: true, call: newCall };
  },

  async getCalls(userId: string) {
    // Use localStorage for calls
    const calls = JSON.parse(localStorage.getItem('calls') || '[]');
    const userCalls = calls.filter((call: any) => 
      call.callerId === userId || call.receiverId === userId
    );
    return { calls: userCalls };
  },

  async updateCallStatus(callId: string, status: string) {
    // Use localStorage for calls
    const calls = JSON.parse(localStorage.getItem('calls') || '[]');
    const updatedCalls = calls.map((call: any) => 
      call.id === callId ? { ...call, status } : call
    );
    localStorage.setItem('calls', JSON.stringify(updatedCalls));
    return { success: true };
  },
};