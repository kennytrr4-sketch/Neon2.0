import { Plus } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";
import { Story } from "../types";
import { StoryViewer } from "./StoryViewer";
import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { CreateStoryDialog } from "./CreateStoryDialog";
import { api } from "../utils/api";

interface StoriesProps {
  stories: Story[];
  onAddStory?: (story: Story) => void;
}

export function Stories({ stories, onAddStory }: StoriesProps) {
  const { user: currentUser } = useAuth();
  const [viewingStory, setViewingStory] = useState<number | null>(null);
  const [showCreateStory, setShowCreateStory] = useState(false);
  const [allStories, setAllStories] = useState<Story[]>([]);

  useEffect(() => {
    // Load stories from API
    loadStories();
    const interval = setInterval(loadStories, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadStories = async () => {
    try {
      const data = await api.getStories();
      if (data.stories) {
        setAllStories(data.stories);
      }
    } catch (error) {
      console.error('Error loading stories:', error);
    }
  };

  if (!currentUser) return null;

  const handleCreateStory = async (file: string) => {
    const newStory = {
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar || '',
      image: file,
    };
    
    try {
      const data = await api.createStory(newStory);
      if (data.success && data.story) {
        setAllStories([data.story, ...allStories]);
        if (onAddStory) {
          onAddStory(data.story);
        }
      }
    } catch (error) {
      console.error('Error creating story:', error);
    }
  };

  const handleViewStory = (index: number) => {
    setViewingStory(index);
  };

  return (
    <Card className="p-2 mb-4">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {/* Create Story */}
        <div
          className="flex-shrink-0 w-28 cursor-pointer group"
          onClick={() => setShowCreateStory(true)}
        >
          <div className="relative h-48 rounded-xl overflow-hidden mb-2" style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
          }}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-white rounded-full p-3 group-hover:scale-110 transition-transform">
                <Plus className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>
          <p className="text-xs text-center">Create Story</p>
        </div>

        {/* Stories */}
        {allStories.map((story, index) => (
          <div
            key={story.id}
            className="flex-shrink-0 w-28 cursor-pointer group"
            onClick={() => handleViewStory(index)}
          >
            <div className="relative h-48 rounded-xl overflow-hidden mb-2">
              <img
                src={story.image}
                alt={story.userName}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-black/60" />
              <Avatar className="absolute top-2 left-2 h-10 w-10 border-4 border-white" style={{
                borderImage: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%) 1'
              }}>
                <AvatarImage src={story.userAvatar} alt={story.userName} />
                <AvatarFallback>{story.userName[0]}</AvatarFallback>
              </Avatar>
              <p className="absolute bottom-2 left-2 right-2 text-white text-xs truncate">
                {story.userName}
              </p>
            </div>
          </div>
        ))}
      </div>

      {viewingStory !== null && (
        <StoryViewer
          stories={allStories}
          initialIndex={viewingStory}
          onClose={() => setViewingStory(null)}
        />
      )}

      <CreateStoryDialog
        isOpen={showCreateStory}
        onClose={() => setShowCreateStory(false)}
        onCreateStory={handleCreateStory}
      />
    </Card>
  );
}