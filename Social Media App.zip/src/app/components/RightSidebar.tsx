import { MoreHorizontal, Search, Video, Phone } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { Messenger } from "./Messenger";
import { useAuth } from "../context/AuthContext";
import { api } from "../utils/api";
 
export function RightSidebar() {
  const { user: currentUser } = useAuth();
  const [friendRequests, setFriendRequests] = useState<any[]>([]);
  const [contacts, setContacts] = useState<any[]>([]);
  const [activeChat, setActiveChat] = useState<{ id: string; name: string; avatar: string } | null>(null);

  useEffect(() => {
    if (currentUser) {
      loadFriendRequests();
      loadContacts();
    }
  }, [currentUser]);

  const loadFriendRequests = () => {
    if (!currentUser) return;

    const requests = JSON.parse(localStorage.getItem('friendRequests') || '{}');
    const receivedRequests = requests[currentUser.id] || [];
    const storedUsers = JSON.parse(localStorage.getItem('mockAccounts') || '[]');
    
    // Get user details for each request (limit to 3 for sidebar)
    const requestUsers = storedUsers
      .filter((u: any) => receivedRequests.includes(u.id) && u.id !== currentUser.id)
      .slice(0, 3)
      .map((u: any) => ({
        id: u.id,
        name: u.name,
        avatar: u.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.name}`,
      }));
    
    setFriendRequests(requestUsers);
  };

  const loadContacts = async () => {
    if (!currentUser) return;
    try {
      const data = await api.getFriends(currentUser.id);
      if (data.friends) {
        setContacts(data.friends);
      }
    } catch (error) {
      console.error('Error loading contacts:', error);
    }
  };

  const handleConfirmFriend = async (userId: string, userName: string) => {
    if (!currentUser) return;

    try {
      await api.addFriend(currentUser.id, userId);

      // Remove from friend requests
      const requests = JSON.parse(localStorage.getItem('friendRequests') || '{}');
      if (requests[currentUser.id]) {
        requests[currentUser.id] = requests[currentUser.id].filter((id: string) => id !== userId);
      }
      localStorage.setItem('friendRequests', JSON.stringify(requests));

      setFriendRequests(friendRequests.filter(user => user.id !== userId));
      loadContacts();
      toast.success(`You are now friends with ${userName}`);
    } catch (error) {
      console.error('Error confirming friend:', error);
    }
  };

  const handleDeleteRequest = (userId: string) => {
    if (!currentUser) return;

    const requests = JSON.parse(localStorage.getItem('friendRequests') || '{}');
    if (requests[currentUser.id]) {
      requests[currentUser.id] = requests[currentUser.id].filter((id: string) => id !== userId);
    }
    localStorage.setItem('friendRequests', JSON.stringify(requests));

    setFriendRequests(friendRequests.filter(user => user.id !== userId));
    toast.info("Friend request deleted");
  };

  const handleContactClick = (user: { id: string; name: string; avatar: string }) => {
    setActiveChat(user);
  };

  return (
    <div className="hidden xl:block w-80 p-4 space-y-6">
      {/* Friend Requests */}
      {friendRequests.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-600">Friend Requests</h3>
            <button className="text-blue-600 text-sm hover:underline">See all</button>
          </div>
          <div className="space-y-3">
            {friendRequests.map((user) => (
              <div key={user.id} className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{user.name}</p>
                  <p className="text-xs text-gray-500">2 mutual friends</p>
                  <div className="flex gap-2 mt-2">
                    <Button size="sm" className="flex-1 h-8" onClick={() => handleConfirmFriend(user.id, user.name)}>
                      Confirm
                    </Button>
                    <Button size="sm" variant="secondary" className="flex-1 h-8" onClick={() => handleDeleteRequest(user.id)}>
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Contacts */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-gray-600">Contacts</h3>
          <div className="flex gap-2">
            <button className="p-1 hover:bg-gray-200 rounded-full">
              <Video className="h-4 w-4 text-gray-600" />
            </button>
            <button className="p-1 hover:bg-gray-200 rounded-full">
              <Search className="h-4 w-4 text-gray-600" />
            </button>
            <button className="p-1 hover:bg-gray-200 rounded-full">
              <MoreHorizontal className="h-4 w-4 text-gray-600" />
            </button>
          </div>
        </div>
        <div className="space-y-2">
          {contacts.length > 0 ? (
            contacts.map((user) => (
              <button
                key={user.id}
                className="flex items-center gap-3 w-full p-2 hover:bg-gray-200 rounded-lg"
                onClick={() => handleContactClick(user)}
              >
                <div className="relative">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name[0]}</AvatarFallback>
                  </Avatar>
                  <span className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white" />
                </div>
                <span className="text-sm">{user.name}</span>
              </button>
            ))
          ) : (
            <p className="text-sm text-gray-500 text-center py-4">No contacts yet</p>
          )}
        </div>
      </div>

      {/* Messenger */}
      {activeChat && (
        <Messenger
          recipientId={activeChat.id}
          recipientName={activeChat.name}
          recipientAvatar={activeChat.avatar}
          onClose={() => setActiveChat(null)}
        />
      )}
    </div>
  );
}