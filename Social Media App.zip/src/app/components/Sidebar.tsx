import { Users, Bookmark, Clock, Video, Store, Calendar, History } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { useAuth } from "../context/AuthContext";
import { Link } from "react-router";

export function Sidebar() {
  const { user } = useAuth();
  
  if (!user) return null;
  
  const menuItems = [
    { icon: Users, name: "Friends", path: "/friends" },
    { icon: History, name: "Login History", path: "/login-history" },
    { icon: Clock, name: "Memories", path: "#" },
    { icon: Bookmark, name: "Saved", path: "#" },
    { icon: Video, name: "Video", path: "#" },
    { icon: Store, name: "Marketplace", path: "#" },
    { icon: Calendar, name: "Events", path: "#" },
  ];

  const isActive = (path: string) => {
    return window.location.pathname === path;
  };

  return (
    <div className="hidden lg:block w-64 p-4 space-y-2">
      <Link
        to={`/profile/${user.id}`}
        className="flex items-center gap-3 p-2 hover:bg-gray-200 rounded-lg"
      >
        <Avatar className="h-9 w-9">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <span className="font-semibold">{user.name}</span>
      </Link>

      {menuItems.map((item) => (
        <Link
          key={item.name}
          to={item.path}
          className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
            isActive(item.path)
              ? "text-blue-600"
              : "hover:bg-gray-100"
          }`}
          style={isActive(item.path) ? {
            background: 'linear-gradient(135deg, #667eea15 0%, #764ba215 100%)'
          } : undefined}
        >
          <item.icon className="h-5 w-5" />
          <span>{item.name}</span>
        </Link>
      ))}
    </div>
  );
}