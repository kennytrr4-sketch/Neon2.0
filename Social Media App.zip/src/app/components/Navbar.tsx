import { Link, useLocation, useNavigate } from "react-router";
import { Home, Users, Bell, Menu, Search, LogOut, Zap, Shield } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { useAuth } from "../context/AuthContext";
import { useApp } from "../context/AppContext";
import { Input } from "./ui/input";
import { useState, useEffect } from "react";

export function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { getUnreadNotificationCount } = useApp();
  const [showLogoutMenu, setShowLogoutMenu] = useState(false);
  const [friendRequestsCount, setFriendRequestsCount] = useState(0);

  useEffect(() => {
    if (user) {
      const requests = JSON.parse(localStorage.getItem('friendRequests') || '{}');
      const receivedRequests = requests[user.id] || [];
      // Filter out requests where the current user is the sender
      const validRequests = receivedRequests.filter((id: string) => id !== user.id);
      setFriendRequestsCount(validRequests.length);
    }
  }, [user, location.pathname]);

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) return null;

  const unreadCount = getUnreadNotificationCount();
  
  return (
    <nav className="bg-white border-b sticky top-0 z-40" style={{ 
      background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
      boxShadow: '0 4px 6px rgba(102, 126, 234, 0.1), 0 2px 4px rgba(102, 126, 234, 0.06)'
    }}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex items-center justify-center h-10 w-10 rounded-xl" style={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)'
              }}>
                <Zap className="h-6 w-6 text-white fill-white" />
              </div>
              <span className="text-2xl font-bold hidden sm:block" style={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}>
                Neon
              </span>
            </Link>
            <div className="hidden md:block relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search Neon"
                className="pl-10 w-64 bg-gray-100 border-none rounded-full"
              />
            </div>
          </div>

          {/* Center Navigation */}
          <div className="hidden md:flex items-center gap-2">
            <Link
              to="/"
              className={`px-8 py-2 rounded-lg transition-colors ${
                isActive("/")
                  ? "text-blue-600 border-b-2 border-blue-600"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Home className="h-6 w-6" />
            </Link>
            <Link
              to="/friends"
              className={`px-8 py-2 rounded-lg transition-colors relative ${
                isActive("/friends")
                  ? "text-blue-600 border-b-2 border-blue-600"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Users className="h-6 w-6" />
              {friendRequestsCount > 0 && (
                <span className="absolute top-1 right-6 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" style={{
                  background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
                }}>
                  {friendRequestsCount}
                </span>
              )}
            </Link>
            <Link
              to="/notifications"
              className={`px-8 py-2 rounded-lg transition-colors relative ${
                isActive("/notifications")
                  ? "text-blue-600 border-b-2 border-blue-600"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Bell className="h-6 w-6" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-6 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" style={{
                  background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
                }}>
                  {unreadCount}
                </span>
              )}
            </Link>
            {user?.isAdmin && (
              <Link
                to="/admin"
                className={`px-8 py-2 rounded-lg transition-colors ${
                  isActive("/admin")
                    ? "text-purple-600 border-b-2 border-purple-600"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <Shield className="h-6 w-6" />
              </Link>
            )}
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            <button className="md:hidden p-2 hover:bg-gray-100 rounded-full">
              <Menu className="h-6 w-6" />
            </button>
            <Link to={`/profile/${user.id}`}>
              <Avatar className="h-8 w-8 cursor-pointer">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>{user.name[0]}</AvatarFallback>
              </Avatar>
            </Link>
            <button
              className="p-2 hover:bg-gray-100 rounded-full"
              onClick={() => setShowLogoutMenu(!showLogoutMenu)}
            >
              <LogOut className="h-6 w-6" />
            </button>
            {showLogoutMenu && (
              <div className="absolute right-0 top-14 bg-white border shadow-md rounded-md z-50">
                <button
                  className="block px-4 py-2 text-gray-800 hover:bg-gray-100 w-full text-left"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden border-t px-4 py-2 flex justify-around">
        <Link
          to="/"
          className={`p-2 ${isActive("/") ? "text-blue-600" : "text-gray-600"}`}
        >
          <Home className="h-6 w-6" />
        </Link>
        <Link
          to="/friends"
          className={`p-2 relative ${isActive("/friends") ? "text-blue-600" : "text-gray-600"}`}
        >
          <Users className="h-6 w-6" />
          {friendRequestsCount > 0 && (
            <span className="absolute top-0 right-0 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" style={{
              background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
            }}>
              {friendRequestsCount}
            </span>
          )}
        </Link>
        <Link
          to="/notifications"
          className={`p-2 relative ${isActive("/notifications") ? "text-blue-600" : "text-gray-600"}`}
        >
          <Bell className="h-6 w-6" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" style={{
              background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
            }}>
              {unreadCount}
            </span>
          )}
        </Link>
      </div>
    </nav>
  );
}