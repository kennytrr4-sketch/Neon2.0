import { useState } from "react";
import { useNavigate } from "react-router";
import { ThumbsUp, MessageCircle, Share2, MoreHorizontal, Heart } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Textarea } from "./ui/textarea";
import { Post as PostType, Comment } from "../types";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";

interface PostCardProps {
  post: PostType;
  onLike: (postId: string) => void;
  onComment: (postId: string, content: string) => void;
  onShare?: (postId: string) => void;
}

export function PostCard({ post, onLike, onComment, onShare }: PostCardProps) {
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");

  if (!currentUser) return null;

  const handleComment = () => {
    if (commentText.trim()) {
      onComment(post.id, commentText);
      setCommentText("");
    }
  };

  const handleShare = () => {
    if (onShare) {
      onShare(post.id);
    }
    toast.success("Post shared to your timeline!");
  };

  const handleMoreOptions = () => {
    toast.info("Post options menu");
  };

  const handleUserClick = (userId: string) => {
    navigate(`/profile/${userId}`);
  };

  return (
    <Card className="mb-4">
      {/* Post Header */}
      <div className="p-4 flex items-start justify-between">
        <div className="flex gap-3">
          <button onClick={() => handleUserClick(post.userId)} className="cursor-pointer">
            <Avatar>
              <AvatarImage src={post.userAvatar} alt={post.userName} />
              <AvatarFallback>{post.userName[0]}</AvatarFallback>
            </Avatar>
          </button>
          <div>
            <button 
              onClick={() => handleUserClick(post.userId)} 
              className="font-semibold hover:underline cursor-pointer"
            >
              {post.userName}
            </button>
            <p className="text-sm text-gray-500">{post.timestamp}</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={handleMoreOptions}>
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="whitespace-pre-wrap">{post.content}</p>
      </div>

      {/* Post Image */}
      {post.image && (
        <div className="w-full">
          <img
            src={post.image}
            alt="Post content"
            className="w-full object-cover max-h-[500px]"
          />
        </div>
      )}

      {/* Stats */}
      <div className="px-4 py-2 flex items-center justify-between text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <div className="flex items-center justify-center h-5 w-5 bg-blue-500 rounded-full">
            <ThumbsUp className="h-3 w-3 text-white fill-white" />
          </div>
          <span>{post.likes}</span>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setShowComments(!showComments)}>
            {post.comments.length} comments
          </button>
          <span>{post.shares} shares</span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-around border-t pt-2">
        <button
          onClick={() => onLike(post.id)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-gray-100 transition-all ${
            post.likedByUser ? "text-blue-600" : "text-gray-600"
          }`}
          style={post.likedByUser ? {
            background: 'linear-gradient(135deg, #667eea15 0%, #764ba215 100%)'
          } : undefined}
        >
          <Heart className={`h-5 w-5 ${post.likedByUser ? "fill-current" : ""}`} />
          <span>Like</span>
        </button>
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-gray-100 text-gray-600 transition-all"
        >
          <MessageCircle className="h-5 w-5" />
          <span>Comment</span>
        </button>
        <button
          onClick={handleShare}
          className="flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-gray-100 text-gray-600 transition-all"
        >
          <Share2 className="h-5 w-5" />
          <span>Share</span>
        </button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="border-t px-4 py-3 space-y-3">
          {/* Existing Comments */}
          {post.comments.map((comment) => (
            <CommentItem key={comment.id} comment={comment} />
          ))}

          {/* Add Comment */}
          <div className="flex gap-2 items-start">
            <Avatar className="h-8 w-8">
              <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
              <AvatarFallback>{currentUser.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 flex gap-2">
              <Textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="min-h-10 resize-none"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleComment();
                  }
                }}
              />
              <Button onClick={handleComment} disabled={!commentText.trim()}>
                Post
              </Button>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}

function CommentItem({ comment }: { comment: Comment }) {
  const navigate = useNavigate();
  
  const handleUserClick = (userId: string) => {
    navigate(`/profile/${userId}`);
  };

  return (
    <div className="flex gap-2">
      <button onClick={() => handleUserClick(comment.userId)} className="cursor-pointer">
        <Avatar className="h-8 w-8">
          <AvatarImage src={comment.userAvatar} alt={comment.userName} />
          <AvatarFallback>{comment.userName[0]}</AvatarFallback>
        </Avatar>
      </button>
      <div className="flex-1">
        <div className="bg-gray-100 rounded-2xl px-3 py-2">
          <button
            onClick={() => handleUserClick(comment.userId)}
            className="text-sm font-semibold hover:underline cursor-pointer"
          >
            {comment.userName}
          </button>
          <p className="text-sm">{comment.content}</p>
        </div>
        <div className="flex gap-3 mt-1 px-3 text-xs text-gray-500">
          <button className="hover:underline">Like</button>
          <button className="hover:underline">Reply</button>
          <span>{comment.timestamp}</span>
          {comment.likes > 0 && (
            <span className="flex items-center gap-1">
              <ThumbsUp className="h-3 w-3 fill-blue-500 text-blue-500" />
              {comment.likes}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}