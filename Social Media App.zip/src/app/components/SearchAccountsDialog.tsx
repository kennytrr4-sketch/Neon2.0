import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Search, UserPlus } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner';
import { api } from '../utils/api';

interface SearchAccountsDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchAccountsDialog({ isOpen, onClose }: SearchAccountsDialogProps) {
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<any[]>([]);
  const [friendRequests, setFriendRequests] = useState<string[]>([]);
  const [friends, setFriends] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen) {
      loadUsers();
      loadFriends();
    }
  }, [isOpen, currentUser]);

  const loadUsers = async () => {
    try {
      const data = await api.getUsers();
      if (data.users) {
        // Filter out current user
        const otherUsers = data.users.filter((u: any) => u.id !== currentUser?.id);
        setAllUsers(otherUsers);
        setFilteredUsers(otherUsers);
      }
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadFriends = async () => {
    if (!currentUser) return;
    
    try {
      const data = await api.getFriends(currentUser.id);
      if (data.friends) {
        const friendIds = data.friends.map((f: any) => f.id);
        setFriends(friendIds);
      }
    } catch (error) {
      console.error('Error loading friends:', error);
    }
  };

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = allUsers.filter(user =>
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(allUsers);
    }
  }, [searchQuery, allUsers]);

  const handleSendRequest = async (userId: string, userName: string) => {
    if (!currentUser) return;

    try {
      const data = await api.addFriend(currentUser.id, userId);
      if (data.success) {
        setFriends([...friends, userId]);
        toast.success(`${userName} is now your friend!`);
      }
    } catch (error) {
      console.error('Error adding friend:', error);
      toast.error('Failed to add friend');
    }
  };

  const isFriend = (userId: string) => {
    return friends.includes(userId);
  };

  const isRequestSent = (userId: string) => {
    return friendRequests.includes(userId);
  };

  const handleViewProfile = (userId: string) => {
    navigate(`/profile/${userId}`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Search Accounts</DialogTitle>
          <DialogDescription>
            Find and add friends by searching for their name or email.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name or email..."
              className="pl-10"
            />
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filteredUsers.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {searchQuery ? 'No accounts found' : 'No other accounts available'}
              </div>
            ) : (
              filteredUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50"
                >
                  <button 
                    onClick={() => handleViewProfile(user.id)}
                    className="flex items-center gap-3 flex-1 text-left"
                  >
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback>{user.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold hover:underline">{user.name}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  </button>
                  <div className="flex gap-2">
                    {isFriend(user.id) ? (
                      <Button disabled variant="secondary" size="sm">
                        Friends
                      </Button>
                    ) : (
                      <Button
                        onClick={() => handleSendRequest(user.id, user.name)}
                        disabled={isRequestSent(user.id)}
                        size="sm"
                      >
                        {isRequestSent(user.id) ? (
                          'Request Sent'
                        ) : (
                          <>
                            <UserPlus className="h-4 w-4 mr-2" />
                            Add Friend
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}