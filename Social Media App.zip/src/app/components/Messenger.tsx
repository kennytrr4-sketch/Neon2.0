import { useState, useRef, useEffect } from "react";
import { X, Send, Phone, Video, MoreHorizontal, Smile, Image as ImageIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { useAuth } from "../context/AuthContext";
import { CallModal } from "./CallModal";
import { api } from "../utils/api";

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
}

interface MessengerProps {
  recipientId: string;
  recipientName: string;
  recipientAvatar: string;
  onClose: () => void;
}

export function Messenger({ recipientId, recipientName, recipientAvatar, onClose }: MessengerProps) {
  const { user: currentUser } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [activeCall, setActiveCall] = useState<'audio' | 'video' | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  if (!currentUser) return null;

  // Create a unique conversation ID
  const conversationId = [currentUser.id, recipientId].sort().join('-');

  useEffect(() => {
    loadMessages();
    // Poll for new messages every 2 seconds
    const interval = setInterval(loadMessages, 2000);
    return () => clearInterval(interval);
  }, [conversationId]);

  const loadMessages = async () => {
    try {
      const data = await api.getMessages(conversationId);
      if (data.messages) {
        setMessages(data.messages);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (newMessage.trim()) {
      const message = {
        senderId: currentUser.id,
        receiverId: recipientId,
        content: newMessage,
      };
      
      try {
        const data = await api.sendMessage(message);
        if (data.success) {
          setMessages([...messages, data.message]);
          setNewMessage("");
        }
      } catch (error) {
        console.error('Error sending message:', error);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleStartAudioCall = () => {
    initiateCall('audio');
  };

  const handleStartVideoCall = () => {
    initiateCall('video');
  };

  const initiateCall = async (callType: 'audio' | 'video') => {
    if (!currentUser) return;

    const callId = `call-${Date.now()}`;
    const call = {
      callId,
      callerId: currentUser.id,
      callerName: currentUser.name,
      callerAvatar: currentUser.avatar || '',
      receiverId: recipientId,
      callType,
    };

    try {
      const data = await api.initiateCall(call);
      if (data.success) {
        // Show calling modal for the caller
        setActiveCall(callType);

        // Poll for call status
        const checkInterval = setInterval(async () => {
          try {
            const callData = await api.getCalls(currentUser.id);
            const thisCall = callData.calls?.find((c: any) => c.id === callId);

            if (thisCall?.status === 'answered') {
              clearInterval(checkInterval);
              // Call was answered, keep the modal open
            } else if (thisCall?.status === 'declined' || thisCall?.status === 'ended') {
              clearInterval(checkInterval);
              setActiveCall(null);
            } else if (!thisCall || thisCall.status !== 'ringing') {
              clearInterval(checkInterval);
              setActiveCall(null);
            }
          } catch (error) {
            console.error('Error checking call status:', error);
          }
        }, 1000);

        // Auto-cancel after 30 seconds if no answer
        setTimeout(async () => {
          clearInterval(checkInterval);
          try {
            await api.updateCallStatus(callId, 'ended');
            setActiveCall(null);
          } catch (error) {
            console.error('Error ending call:', error);
          }
        }, 30000);
      }
    } catch (error) {
      console.error('Error initiating call:', error);
    }
  };

  const handleEndCall = async () => {
    if (!currentUser) return;

    try {
      // Find active calls with this recipient
      const callData = await api.getCalls(currentUser.id);
      const activeCallWithRecipient = callData.calls?.find((call: any) =>
        (call.callerId === currentUser.id && call.receiverId === recipientId) ||
        (call.receiverId === currentUser.id && call.callerId === recipientId)
      );

      if (activeCallWithRecipient) {
        await api.updateCallStatus(activeCallWithRecipient.id, 'ended');
      }

      setActiveCall(null);
    } catch (error) {
      console.error('Error ending call:', error);
      setActiveCall(null);
    }
  };

  return (
    <>
      <div className="fixed bottom-0 right-4 w-80 h-96 bg-white rounded-t-lg shadow-2xl border border-gray-200 flex flex-col z-50">
        {/* Header */}
        <div className="flex items-center justify-between p-3 border-b bg-white rounded-t-lg">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={recipientAvatar} alt={recipientName} />
              <AvatarFallback>{recipientName[0]}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-sm">{recipientName}</p>
              <p className="text-xs text-green-600">Active now</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleStartAudioCall}>
              <Phone className="h-4 w-4 text-blue-600" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleStartVideoCall}>
              <Video className="h-4 w-4 text-blue-600" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-gray-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.senderId === currentUser.id ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[70%] rounded-2xl px-3 py-2 ${
                  message.senderId === currentUser.id
                    ? "bg-blue-600 text-white"
                    : "bg-gray-200 text-gray-900"
                }`}
              >
                <p className="text-sm">{message.content}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-2 border-t bg-white flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
            <ImageIcon className="h-4 w-4 text-blue-600" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
            <Smile className="h-4 w-4 text-blue-600" />
          </Button>
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1 h-8 text-sm"
          />
          <Button
            onClick={handleSend}
            size="icon"
            className="h-8 w-8 flex-shrink-0"
            disabled={!newMessage.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Call Modal */}
      {activeCall && (
        <CallModal
          recipientName={recipientName}
          recipientAvatar={recipientAvatar}
          callType={activeCall}
          onEnd={handleEndCall}
        />
      )}
    </>
  );
}