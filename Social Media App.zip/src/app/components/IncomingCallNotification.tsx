import { useEffect, useState } from 'react';
import { Phone, PhoneOff } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';

interface IncomingCallNotificationProps {
  callerName: string;
  callerAvatar: string;
  callerId: string;
  callType: 'audio' | 'video';
  callId: string;
  onAnswer: () => void;
  onDecline: () => void;
}

export function IncomingCallNotification({
  callerName,
  callerAvatar,
  callType,
  onAnswer,
  onDecline,
}: IncomingCallNotificationProps) {
  const [isRinging, setIsRinging] = useState(true);

  // Play ringtone sound (simulated with animation)
  useEffect(() => {
    // In a real app, you would play an actual audio file here
    // const audio = new Audio('/ringtone.mp3');
    // audio.loop = true;
    // audio.play();
    // return () => audio.pause();

    const ringTimeout = setTimeout(() => {
      setIsRinging(false);
    }, 30000); // Auto-decline after 30 seconds

    return () => clearTimeout(ringTimeout);
  }, []);

  if (!isRinging) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full mx-4 animate-in slide-in-from-bottom-4">
        {/* Caller Info */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-4">
            <Avatar className="h-32 w-32 ring-4 ring-purple-200 animate-pulse">
              <AvatarImage src={callerAvatar} alt={callerName} />
              <AvatarFallback className="text-4xl">{callerName[0]}</AvatarFallback>
            </Avatar>
            {/* Pulsing ring animation */}
            <div className="absolute inset-0 rounded-full ring-4 ring-purple-400 animate-ping opacity-75" />
          </div>
          <h2 className="text-2xl font-semibold mb-2">{callerName}</h2>
          <p className="text-gray-600 flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Incoming {callType} call...
          </p>
        </div>

        {/* Ringtone indicator */}
        <div className="flex justify-center gap-2 mb-8">
          <div className="w-2 h-8 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-8 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '100ms' }} />
          <div className="w-2 h-8 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '200ms' }} />
          <div className="w-2 h-8 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '300ms' }} />
          <div className="w-2 h-8 bg-purple-500 rounded-full animate-pulse" style={{ animationDelay: '400ms' }} />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 justify-center">
          <Button
            onClick={onDecline}
            size="lg"
            variant="destructive"
            className="rounded-full h-16 w-16 flex-shrink-0"
          >
            <PhoneOff className="h-6 w-6" />
          </Button>
          <Button
            onClick={onAnswer}
            size="lg"
            className="rounded-full h-16 w-16 flex-shrink-0 bg-green-500 hover:bg-green-600"
          >
            <Phone className="h-6 w-6" />
          </Button>
        </div>

        <p className="text-center text-sm text-gray-500 mt-4">
          Click answer to accept the call
        </p>
      </div>
    </div>
  );
}
