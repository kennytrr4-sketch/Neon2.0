import { useState, useRef } from 'react';
import { X, Upload, Image as ImageIcon, Video } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import { Button } from './ui/button';
import { toast } from 'sonner';

interface CreateStoryDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateStory: (file: string) => void;
}

export function CreateStoryDialog({ isOpen, onClose, onCreateStory }: CreateStoryDialogProps) {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [fileType, setFileType] = useState<'image' | 'video' | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedFile(reader.result as string);
        setFileType(file.type.startsWith('video') ? 'video' : 'image');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreate = () => {
    if (selectedFile) {
      onCreateStory(selectedFile);
      toast.success('Story created successfully!');
      setSelectedFile(null);
      setFileType(null);
      onClose();
    }
  };

  const handleClose = () => {
    setSelectedFile(null);
    setFileType(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Create Story</DialogTitle>
          <DialogDescription>
            Upload a photo or video to share your story.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!selectedFile ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center cursor-pointer hover:border-blue-500 transition-colors"
            >
              <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p className="text-sm text-gray-600 mb-2">
                Click to upload photo or video
              </p>
              <p className="text-xs text-gray-400">
                Support for JPG, PNG, GIF, MP4, MOV
              </p>
            </div>
          ) : (
            <div className="relative">
              {fileType === 'image' ? (
                <img
                  src={selectedFile}
                  alt="Story preview"
                  className="w-full h-96 object-cover rounded-lg"
                />
              ) : (
                <video
                  src={selectedFile}
                  controls
                  className="w-full h-96 object-cover rounded-lg"
                />
              )}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white"
                onClick={() => {
                  setSelectedFile(null);
                  setFileType(null);
                }}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            className="hidden"
            onChange={handleFileSelect}
          />

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button onClick={handleCreate} disabled={!selectedFile}>
              Share Story
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}