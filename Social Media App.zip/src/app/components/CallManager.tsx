import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { IncomingCallNotification } from './IncomingCallNotification';
import { CallModal } from './CallModal';
import { api } from '../utils/api';

interface IncomingCall {
  id: string;
  callerId: string;
  callerName: string;
  callerAvatar: string;
  receiverId: string;
  callType: 'audio' | 'video';
  status: 'ringing' | 'answered' | 'declined' | 'ended';
  timestamp: number;
}

export function CallManager() {
  const { user } = useAuth();
  const [incomingCall, setIncomingCall] = useState<IncomingCall | null>(null);
  const [activeCall, setActiveCall] = useState<IncomingCall | null>(null);
  const [receiverUser, setReceiverUser] = useState<any>(null);

  useEffect(() => {
    if (!user) return;

    // Poll for incoming calls every second (forced HMR update to clear stale polling)
    const interval = setInterval(() => {
      checkForIncomingCalls();
    }, 1000);

    return () => clearInterval(interval);
  }, [user]);

  const checkForIncomingCalls = async () => {
    if (!user) return;

    try {
      const data = await api.getCalls(user.id);
      if (data.calls && data.calls.length > 0) {
        // Find any ringing calls for this user
        const ringingCall = data.calls.find(
          (call: IncomingCall) => call.status === 'ringing' && call.receiverId === user.id
        );

        if (ringingCall && (!incomingCall || incomingCall.id !== ringingCall.id)) {
          setIncomingCall(ringingCall);
        }

        // Check if a call was answered by the other party
        const answeredCall = data.calls.find(
          (call: IncomingCall) => call.status === 'answered' && call.callerId === user.id && !activeCall
        );

        if (answeredCall) {
          // Load receiver user data
          const otherUserId = answeredCall.receiverId;
          const userData = await api.getUser(otherUserId);
          if (userData.user) {
            setReceiverUser(userData.user);
          }
          setActiveCall(answeredCall);
          setIncomingCall(null);
        }
      }
    } catch (error) {
      console.error('Error checking for incoming calls:', error);
    }
  };

  const handleAnswerCall = async () => {
    if (!incomingCall || !user) return;

    try {
      await api.updateCallStatus(incomingCall.id, 'answered');
      setActiveCall(incomingCall);
      setIncomingCall(null);
    } catch (error) {
      console.error('Error answering call:', error);
    }
  };

  const handleDeclineCall = async () => {
    if (!incomingCall || !user) return;

    try {
      await api.updateCallStatus(incomingCall.id, 'declined');
      setIncomingCall(null);
    } catch (error) {
      console.error('Error declining call:', error);
    }
  };

  const handleEndCall = async () => {
    if (!activeCall || !user) return;

    try {
      await api.updateCallStatus(activeCall.id, 'ended');
      setActiveCall(null);
      setReceiverUser(null);
    } catch (error) {
      console.error('Error ending call:', error);
    }
  };

  if (!user) return null;

  return (
    <>
      {incomingCall && (
        <IncomingCallNotification
          callerName={incomingCall.callerName}
          callerAvatar={incomingCall.callerAvatar}
          callerId={incomingCall.callerId}
          callType={incomingCall.callType}
          callId={incomingCall.id}
          onAnswer={handleAnswerCall}
          onDecline={handleDeclineCall}
        />
      )}

      {activeCall && (
        <CallModal
          recipientName={activeCall.callerId === user.id ?
            // If current user is the caller, show receiver's name
            receiverUser?.name || 'Unknown' :
            // If current user is the receiver, show caller's name
            activeCall.callerName
          }
          recipientAvatar={activeCall.callerId === user.id ?
            // If current user is the caller, show receiver's avatar
            receiverUser?.avatar || '' :
            // If current user is the receiver, show caller's avatar
            activeCall.callerAvatar
          }
          callType={activeCall.callType}
          onEnd={handleEndCall}
          isIncoming={activeCall.receiverId === user.id}
        />
      )}
    </>
  );
}