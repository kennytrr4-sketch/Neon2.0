import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "./utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md text-sm font-medium transition-all",
  {
    variants: {
      variant: {
        default:
          "text-white hover:opacity-90 shadow-md",
        primary:
          "text-white hover:opacity-90 shadow-md",
        secondary:
          "bg-gray-100 text-gray-900 hover:bg-gray-200 shadow-sm",
        outline:
          "border-2 border-gray-300 bg-transparent hover:bg-gray-100",
        ghost:
          "hover:bg-gray-100",
        destructive:
          "bg-red-600 text-white hover:bg-red-700 shadow-md",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-8 px-3 text-xs",
        lg: "h-12 px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

function Button({
  className,
  variant = "default",
  size,
  asChild = false,
  style,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  }) {
  const Comp = asChild ? Slot : "button";

  // Apply gradient for default and primary variants
  const gradientStyle = (variant === "default" || variant === "primary") ? {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    ...style
  } : style;

  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      style={gradientStyle}
      {...props}
    />
  );
}

export { Button, buttonVariants };
