import { useEffect, useState } from 'react';
import { X, Phone, Video, Mic, MicOff, VideoOff, PhoneOff } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { toast } from 'sonner';

interface CallModalProps {
  recipientName: string;
  recipientAvatar: string;
  callType: 'audio' | 'video';
  onEnd: () => void;
  isIncoming?: boolean;
}

export function CallModal({ recipientName, recipientAvatar, callType, onEnd, isIncoming = false }: CallModalProps) {
  const [callStatus, setCallStatus] = useState<'ringing' | 'connected' | 'ended'>(isIncoming ? 'connected' : 'ringing');
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);

  // Simulate call connection after 2-3 seconds (only if outgoing call)
  useEffect(() => {
    if (!isIncoming) {
      const connectTimeout = setTimeout(() => {
        setCallStatus('connected');
        toast.success(`Connected with ${recipientName}`);
      }, Math.random() * 1000 + 2000);

      return () => clearTimeout(connectTimeout);
    }
  }, [recipientName, isIncoming]);

  // Call duration timer
  useEffect(() => {
    if (callStatus === 'connected') {
      const interval = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [callStatus]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setCallStatus('ended');
    toast.info(`Call ended - Duration: ${formatDuration(duration)}`);
    setTimeout(() => {
      onEnd();
    }, 500);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    toast.info(isMuted ? 'Microphone on' : 'Microphone muted');
  };

  const toggleVideo = () => {
    setIsVideoOff(!isVideoOff);
    toast.info(isVideoOff ? 'Camera on' : 'Camera off');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
      <div className="w-full max-w-2xl h-[600px] bg-gradient-to-br from-purple-900 to-purple-700 rounded-lg shadow-2xl flex flex-col relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ 
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }} />
        </div>

        {/* Header */}
        <div className="relative p-6 flex justify-between items-start">
          <div className="text-white">
            <h2 className="text-2xl font-semibold mb-1">{recipientName}</h2>
            <p className="text-purple-200 text-sm">
              {callStatus === 'ringing' && 'Calling...'}
              {callStatus === 'connected' && formatDuration(duration)}
              {callStatus === 'ended' && 'Call Ended'}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleEndCall}
            className="text-white hover:bg-white/10"
          >
            <X className="h-6 w-6" />
          </Button>
        </div>

        {/* Video/Avatar Display */}
        <div className="relative flex-1 flex items-center justify-center p-8">
          {callType === 'video' && callStatus === 'connected' && !isVideoOff ? (
            <div className="w-full h-full bg-gray-900 rounded-lg flex items-center justify-center">
              {/* Simulated video feed */}
              <div className="relative w-full h-full">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Avatar className="h-48 w-48">
                    <AvatarImage src={recipientAvatar} alt={recipientName} />
                    <AvatarFallback className="text-6xl">{recipientName[0]}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute top-4 right-4 w-32 h-24 bg-gray-800 rounded-lg border-2 border-white flex items-center justify-center">
                  <span className="text-white text-xs">You</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <Avatar className="h-48 w-48 mb-6 ring-4 ring-white/20">
                <AvatarImage src={recipientAvatar} alt={recipientName} />
                <AvatarFallback className="text-6xl">{recipientName[0]}</AvatarFallback>
              </Avatar>
              {callStatus === 'ringing' && (
                <div className="flex gap-2">
                  <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="relative p-8 flex justify-center gap-4">
          {callType === 'audio' ? (
            <>
              <Button
                size="lg"
                onClick={toggleMute}
                className={`rounded-full h-16 w-16 ${
                  isMuted ? 'bg-red-500 hover:bg-red-600' : 'bg-white/20 hover:bg-white/30'
                } text-white`}
              >
                {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </Button>
            </>
          ) : (
            <>
              <Button
                size="lg"
                onClick={toggleMute}
                className={`rounded-full h-16 w-16 ${
                  isMuted ? 'bg-red-500 hover:bg-red-600' : 'bg-white/20 hover:bg-white/30'
                } text-white`}
              >
                {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </Button>
              <Button
                size="lg"
                onClick={toggleVideo}
                className={`rounded-full h-16 w-16 ${
                  isVideoOff ? 'bg-red-500 hover:bg-red-600' : 'bg-white/20 hover:bg-white/30'
                } text-white`}
              >
                {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
              </Button>
            </>
          )}
          <Button
            size="lg"
            onClick={handleEndCall}
            className="rounded-full h-16 w-16 bg-red-500 hover:bg-red-600 text-white"
          >
            <PhoneOff className="h-6 w-6" />
          </Button>
        </div>
      </div>
    </div>
  );
}
