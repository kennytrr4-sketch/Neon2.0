import { Outlet, Navigate } from "react-router";
import { Navbar } from "./Navbar";
import { useAuth } from "../context/AuthContext";
import { CallManager } from "./CallManager";

export function Layout() {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main>
        <Outlet />
      </main>
      <CallManager />
    </div>
  );
}