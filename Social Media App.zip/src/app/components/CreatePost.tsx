import { useState, useRef } from "react";
import { Image, Video, X } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Card } from "./ui/card";
import { useAuth } from "../context/AuthContext";

interface CreatePostProps {
  onPost: (content: string, image?: string) => void;
}

export function CreatePost({ onPost }: CreatePostProps) {
  const { user } = useAuth();
  const [content, setContent] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  if (!user) return null;

  const handlePost = () => {
    if (content.trim() || selectedImage) {
      onPost(content, selectedImage || undefined);
      setContent("");
      setSelectedImage(null);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    if (imageInputRef.current) imageInputRef.current.value = "";
    if (videoInputRef.current) videoInputRef.current.value = "";
  };

  return (
    <Card className="p-4 mb-4">
      <div className="flex gap-3">
        <Avatar>
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="space-y-3">
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={`What's on your mind, ${user.name}?`}
              className="min-h-24 resize-none border-none focus-visible:ring-0 p-0"
              autoFocus
            />
            <div className="flex items-center justify-between pt-3 border-t">
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => imageInputRef.current?.click()}
                >
                  <Image className="h-5 w-5 text-green-600 mr-2" />
                  Photo
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => videoInputRef.current?.click()}
                >
                  <Video className="h-5 w-5 text-red-600 mr-2" />
                  Video
                </Button>
              </div>
              <Button onClick={handlePost} disabled={!content.trim() && !selectedImage}>
                Post
              </Button>
            </div>
          </div>
          {selectedImage && (
            <div className="mt-3 relative">
              <img
                src={selectedImage}
                alt="Selected"
                className="w-full h-48 object-cover rounded-lg"
              />
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 bg-black/50 hover:bg-black/70"
                onClick={removeImage}
              >
                <X className="h-5 w-5 text-white" />
              </Button>
            </div>
          )}
        </div>
      </div>
      {!selectedImage && (
        <div className="flex gap-2 mt-3 pt-3 border-t">
          <Button variant="ghost" className="flex-1" onClick={() => videoInputRef.current?.click()}>
            <Video className="h-5 w-5 text-red-600 mr-2" />
            Live video
          </Button>
          <Button variant="ghost" className="flex-1" onClick={() => imageInputRef.current?.click()}>
            <Image className="h-5 w-5 text-green-600 mr-2" />
            Photo/video
          </Button>
        </div>
      )}
      <input
        type="file"
        accept="image/*"
        ref={imageInputRef}
        className="hidden"
        onChange={handleImageSelect}
      />
      <input
        type="file"
        accept="video/*"
        ref={videoInputRef}
        className="hidden"
        onChange={handleVideoSelect}
      />
    </Card>
  );
}