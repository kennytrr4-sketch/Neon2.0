import { Post, Notification, Story } from "../types";

// Empty users array - users are now managed through authentication
export const users: any[] = [];

// Empty stories array - to be populated by authenticated users
export const stories: Story[] = [];

// Sample posts structure (can be empty or have sample posts)
export const initialPosts: Post[] = [];

// Empty notifications
export const notifications: Notification[] = [];

export const friendRequests: any[] = [];

export const suggestedFriends: any[] = [];
